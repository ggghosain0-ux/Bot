#!/bin/bash

# =================================================================-------------
# VPSDEPLOYBOT Automated Installation and Startup Script
# =================================================================-------------

# Use set -e to exit immediately if a command exits with a non-zero status
set -e

# Colored Output Codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper Functions for Logging
log_success() {
    echo -e "${GREEN}[SUCCESS] $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

log_error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

log_info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

echo -e "${BLUE}"
echo "========================================================================="
echo "                  VPSDEPLOYBOT INSTALLATION WIZARD                       "
echo "========================================================================="
echo -e "${NC}"

# 1. Verification of Base Script Files
log_info "Verifying essential files..."
if [ ! -f "bot.py" ]; then
    log_error "Essential file 'bot.py' is missing! Installation aborted."
    exit 1
fi

if [ ! -f ".env" ]; then
    log_warning ".env file not found, creating a default one..."
    echo "DISCORD_TOKEN=YOUR_DISCORD_TOKEN_HERE" > .env
fi

# 2. Manual Installation of Python Packages
log_info "Manually installing python dependencies with system packages bypass..."
if command -v pip3 >/dev/null 2>&1; then
    pip3 install --break-system-packages discord.py python-dotenv requests
elif command -v pip >/dev/null 2>&1; then
    pip install --break-system-packages discord.py python-dotenv requests
else
    log_info "pip/pip3 not found in PATH, attempting via python3 -m pip..."
    python3 -m pip install --break-system-packages discord.py python-dotenv requests
fi

log_success "Dependency installation complete!"

# 3. Configure Environment Variables
log_info "Opening environment file (.env) for configuration via nano..."
if command -v nano >/dev/null 2>&1; then
    nano .env
else
    log_warning "nano editor is not available in this environment. Please configure .env manually if needed."
fi

# 4. Start the Application
log_success "All setup steps complete! Launching VPSDEPLOYBOT..."
echo "========================================================================="
python3 bot.py
