import asyncio
import subprocess
import json
import logging
import os
import random
import shlex
import shutil
import sqlite3
import sys
import threading
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import discord
from discord import app_commands
import requests
from discord.ext import commands
from dotenv import load_dotenv

# Load environmental configurations
load_dotenv()

DISCORD_TOKEN = os.getenv('DISCORD_TOKEN', '')
BOT_NAME = os.getenv('BOT_NAME', 'VPSDEPLOYBOT')
PREFIX = os.getenv('PREFIX', 'h!')
YOUR_SERVER_IP = os.getenv('YOUR_SERVER_IP', '127.0.0.1')
MAIN_ADMIN_ID = int(os.getenv('MAIN_ADMIN_ID', '1365911814747066388'))
VPS_USER_ROLE_ID = int(os.getenv('VPS_USER_ROLE_ID', '1476612765404758106'))
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')
BOT_VERSION = os.getenv('BOT_VERSION', '1.0')
BOT_DEVELOPER = os.getenv('BOT_DEVELOPER', 'Console')

# Curated OS templates for installation / re-installation
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS", "value": "ubuntu:20.04"},
    {"label": "Ubuntu 22.04 LTS", "value": "ubuntu:22.04"},
    {"label": "Ubuntu 24.04 LTS", "value": "ubuntu:24.04"},
    {"label": "Debian 10 (Buster)", "value": "images:debian/10"},
    {"label": "Debian 11 (Bullseye)", "value": "images:debian/11"},
    {"label": "Debian 12 (Bookworm)", "value": "images:debian/12"},
    {"label": "Debian 13 (Trixie)", "value": "images:debian/13"},
]

# Configure structured system logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(f'{BOT_NAME.lower()}_vps_bot')

def log_system_event(event_type: str, message: str, level: str = "info", exception: Exception = None):
    log_msg = f"[{event_type.upper()}] {message}"
    if level == "error":
        logger.error(log_msg, exc_info=exception)
    elif level == "warning":
        logger.warning(log_msg)
    else:
        logger.info(log_msg)

# SQLite Datastore Engine
def get_db():
    conn = sqlite3.connect('vps.db', timeout=10.0)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT PRIMARY KEY
        )''')
        cur.execute('INSERT OR IGNORE INTO admins (user_id) VALUES (?)', (str(MAIN_ADMIN_ID),))
        cur.execute('''CREATE TABLE IF NOT EXISTS nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            location TEXT,
            total_vps INTEGER,
            tags TEXT DEFAULT '[]',
            api_key TEXT,
            url TEXT,
            is_local INTEGER DEFAULT 0
        )''')
        cur.execute('SELECT COUNT(*) FROM nodes WHERE is_local = 1')
        if cur.fetchone()[0] == 0:
            cur.execute('INSERT INTO nodes (name, location, total_vps, tags, api_key, url, is_local) VALUES (?, ?, ?, ?, ?, ?, ?)',
                        ('Local Node', 'Local', 100, '[]', None, None, 1))
        cur.execute('''CREATE TABLE IF NOT EXISTS vps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            node_id INTEGER NOT NULL DEFAULT 1,
            container_name TEXT UNIQUE NOT NULL,
            ram TEXT NOT NULL,
            cpu TEXT NOT NULL,
            storage TEXT NOT NULL,
            config TEXT NOT NULL,
            os_version TEXT DEFAULT 'ubuntu:22.04',
            status TEXT DEFAULT 'stopped',
            suspended INTEGER DEFAULT 0,
            whitelisted INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            shared_with TEXT DEFAULT '[]',
            suspension_history TEXT DEFAULT '[]'
        )''')
        cur.execute('''CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )''')
        for key, val in [('cpu_threshold', '90'), ('ram_threshold', '90')]:
            cur.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (key, val))
        cur.execute('''CREATE TABLE IF NOT EXISTS port_allocations (
            user_id TEXT PRIMARY KEY,
            allocated_ports INTEGER DEFAULT 0
        )''')
        cur.execute('''CREATE TABLE IF NOT EXISTS port_forwards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            vps_container TEXT NOT NULL,
            vps_port INTEGER NOT NULL,
            host_port INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )''')
        conn.commit()

# Initialize core DB schemas
init_db()

# Memory caches synced with database
vps_data: Dict[str, List[Dict[str, Any]]] = {}
admin_data: Dict[str, List[str]] = {'admins': []}

def reload_caches():
    global vps_data, admin_data
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps')
        vps_rows = cur.fetchall()
        vps_data.clear()
        for row in vps_rows:
            uid = row['user_id']
            if uid not in vps_data:
                vps_data[uid] = []
            vps = dict(row)
            vps['shared_with'] = json.loads(vps['shared_with'])
            vps['suspension_history'] = json.loads(vps['suspension_history'])
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_data[uid].append(vps)
        
        cur.execute('SELECT user_id FROM admins')
        admin_data['admins'] = [r['user_id'] for r in cur.fetchall()]

reload_caches()

def get_setting(key: str, default: Any = None) -> Any:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
        row = cur.fetchone()
        return row[0] if row else default

def set_setting(key: str, value: str):
    with get_db() as conn:
        conn.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
        conn.commit()

# Cache thresholds
CPU_THRESHOLD = int(get_setting('cpu_threshold', 90))
RAM_THRESHOLD = int(get_setting('ram_threshold', 90))

# Multi-node API models and database queries
def get_nodes() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes')
        res = [dict(r) for r in cur.fetchall()]
        for r in res:
            r['tags'] = json.loads(r['tags'])
        return res

def get_node(node_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes WHERE id = ?', (node_id,))
        row = cur.fetchone()
        if row:
            node = dict(row)
            node['tags'] = json.loads(node['tags'])
            return node
    return None

def get_current_vps_count(node_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM vps WHERE node_id = ?', (node_id,))
        return cur.fetchone()[0]

def save_vps_data():
    with get_db() as conn:
        cur = conn.cursor()
        for uid, lst in vps_data.items():
            for v in lst:
                shared = json.dumps(v.get('shared_with', []))
                history = json.dumps(v.get('suspension_history', []))
                susp = 1 if v.get('suspended') else 0
                white = 1 if v.get('whitelisted') else 0
                os_v = v.get('os_version', 'ubuntu:22.04')
                c_at = v.get('created_at', datetime.now().isoformat())
                node_id = v.get('node_id', 1)
                
                if v.get('id') is None:
                    cur.execute('''INSERT INTO vps (user_id, node_id, container_name, ram, cpu, storage, config, os_version, status, suspended, whitelisted, created_at, shared_with, suspension_history)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                                (uid, node_id, v['container_name'], v['ram'], v['cpu'], v['storage'], v['config'], os_v, v['status'], susp, white, c_at, shared, history))
                    v['id'] = cur.lastrowid
                else:
                    cur.execute('''UPDATE vps SET user_id = ?, node_id = ?, container_name = ?, ram = ?, cpu = ?, storage = ?, config = ?, os_version = ?, status = ?, suspended = ?, whitelisted = ?, shared_with = ?, suspension_history = ?
                                   WHERE id = ?''',
                                (uid, node_id, v['container_name'], v['ram'], v['cpu'], v['storage'], v['config'], os_v, v['status'], susp, white, shared, history, v['id']))
        conn.commit()
    reload_caches()

def save_admin_data():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM admins')
        for aid in admin_data['admins']:
            cur.execute('INSERT OR IGNORE INTO admins (user_id) VALUES (?)', (aid,))
        conn.commit()
    reload_caches()

# Port allocation database logic
def get_user_allocation(user_id: str) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT allocated_ports FROM port_allocations WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        return row[0] if row else 0

def get_user_used_ports(user_id: str) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM port_forwards WHERE user_id = ?', (user_id,))
        return cur.fetchone()[0]

def allocate_ports(user_id: str, amount: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT allocated_ports FROM port_allocations WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        curr_alloc = row[0] if row else 0
        cur.execute('INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports) VALUES (?, ?)', (user_id, curr_alloc + amount))
        conn.commit()

def deallocate_ports(user_id: str, amount: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT allocated_ports FROM port_allocations WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        if row:
            rem = max(0, row[0] - amount)
            cur.execute('UPDATE port_allocations SET allocated_ports = ? WHERE user_id = ?', (rem, user_id))
            conn.commit()

def get_available_host_port(node_id: int) -> Optional[int]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT host_port FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)', (node_id,))
        used_ports = set(r[0] for r in cur.fetchall())
    for _ in range(200):
        p = random.randint(20000, 50000)
        if p not in used_ports:
            return p
    return None

def find_node_id_for_container(container_name: str) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT node_id FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        return row[0] if row else 1

# LXC Command Router
async def execute_lxc(container_name: str, command: str, timeout=120, node_id: Optional[int] = None) -> Any:
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    node = get_node(node_id)
    if not node:
        raise Exception(f"Configuration node {node_id} is unregistered or invalid.")
    
    full_cmd = f"lxc {command}"
    if node['is_local']:
        try:
            parsed = shlex.split(full_cmd)
            proc = await asyncio.create_subprocess_exec(
                *parsed,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise asyncio.TimeoutError(f"Local operation execution timed out after {timeout} seconds.")
            
            if proc.returncode != 0:
                err_msg = stderr.decode(errors='replace').strip() if stderr else "Process returned structural exit failure"
                raise Exception(f"LXC execution fault: {err_msg} | Command: {full_cmd}")
            return stdout.decode(errors='replace').strip() if stdout else True
        except Exception as e:
            logger.error(f"Local LXC Error: {full_cmd} | details: {e}")
            raise
    else:
        url = f"{node['url']}/api/execute"
        params = {"api_key": node["api_key"]}
        payload = {"command": full_cmd}
        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None,
                lambda: requests.post(url, json=payload, params=params, timeout=timeout)
            )
            response.raise_for_status()
            res = response.json()
            if res.get("returncode", 1) != 0:
                err_msg = res.get("stderr", "Command structure processing failure on node")
                raise Exception(f"Node execution fault: {err_msg} | Command: {full_cmd}")
            return res.get("stdout", True)
        except Exception as e:
            logger.error(f"Remote LXC Error on node '{node['name']}': {e}")
            raise Exception(f"Distributed transmission error on '{node['name']}': {e}")

async def create_port_forward(user_id: str, container: str, vps_port: int, node_id: int) -> Optional[int]:
    host_port = get_available_host_port(node_id)
    if not host_port:
        return None
    try:
        await execute_lxc(container, f"config device add {container} tcp_proxy_{host_port} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}", node_id=node_id)
        await execute_lxc(container, f"config device add {container} udp_proxy_{host_port} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}", node_id=node_id)
        with get_db() as conn:
            conn.execute('INSERT INTO port_forwards (user_id, vps_container, vps_port, host_port, created_at) VALUES (?, ?, ?, ?, ?)',
                         (user_id, container, vps_port, host_port, datetime.now().isoformat()))
            conn.commit()
        return host_port
    except Exception as e:
        logger.error(f"Port forwarding setup failure: {e}")
        return None

async def remove_port_forward(forward_id: int, is_admin: bool = False) -> Tuple[bool, Optional[str]]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT user_id, vps_container, host_port FROM port_forwards WHERE id = ?', (forward_id,))
        row = cur.fetchone()
        if not row:
            return False, None
        uid, container, host_port = row['user_id'], row['vps_container'], row['host_port']
        node_id = find_node_id_for_container(container)
        try:
            await execute_lxc(container, f"config device remove {container} tcp_proxy_{host_port}", node_id=node_id)
            await execute_lxc(container, f"config device remove {container} udp_proxy_{host_port}", node_id=node_id)
            cur.execute('DELETE FROM port_forwards WHERE id = ?', (forward_id,))
            conn.commit()
            return True, uid
        except Exception as e:
            logger.error(f"Port forwarding teardown failure on forward ID {forward_id}: {e}")
            return False, None

async def recreate_port_forwards(container_name: str) -> int:
    node_id = find_node_id_for_container(container_name)
    readded = 0
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT vps_port, host_port FROM port_forwards WHERE vps_container = ?', (container_name,))
        rows = cur.fetchall()
    for row in rows:
        vp, hp = row['vps_port'], row['host_port']
        try:
            await execute_lxc(container_name, f"config device add {container_name} tcp_proxy_{hp} proxy listen=tcp:0.0.0.0:{hp} connect=tcp:127.0.0.1:{vp}", node_id=node_id)
            await execute_lxc(container_name, f"config device add {container_name} udp_proxy_{hp} proxy listen=udp:0.0.0.0:{hp} connect=udp:127.0.0.1:{vp}", node_id=node_id)
            readded += 1
        except Exception as e:
            logger.error(f"Error restoring port mapping HP {hp} -> VP {vp}: {e}")
    return readded

# Security policies & profiles configurations
async def apply_lxc_config(container_name: str, node_id: int):
    try:
        await execute_lxc(container_name, f"config set {container_name} security.nesting true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.privileged true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.syscalls.intercept.mknod true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.syscalls.intercept.setxattr true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables,netlink_diag,br_netfilter", node_id=node_id)
        try:
            await execute_lxc(container_name, f"config device add {container_name} fuse unix-char path=/dev/fuse", node_id=node_id)
        except Exception:
            pass
        raw_lxc_config = (
            "lxc.apparmor.profile = unconfined\n"
            "lxc.apparmor.allow_nesting = 1\n"
            "lxc.apparmor.allow_incomplete = 1\n"
            "lxc.cap.drop =\n"
            "lxc.cgroup.devices.allow = a\n"
            "lxc.cgroup2.devices.allow = a\n"
            "lxc.mount.auto = proc:rw sys:rw cgroup:rw shmounts:rw\n"
            "lxc.mount.entry = /dev/fuse dev/fuse none bind,create=file 0 0\n"
        )
        await execute_lxc(container_name, f"config set {container_name} raw.lxc '{raw_lxc_config}'", node_id=node_id)
        logger.info(f"LXC security policies applied to {container_name} (Node: {node_id})")
    except Exception as e:
        logger.error(f"LXC security adjustments failed on {container_name}: {e}")

async def apply_internal_permissions(container_name: str, node_id: int):
    try:
        await asyncio.sleep(4)
        commands = [
            "mkdir -p /etc/sysctl.d/",
            "echo 'net.ipv4.ip_unprivileged_port_start=0' > /etc/sysctl.d/99-custom.conf",
            "echo 'net.ipv4.ping_group_range=0 2147483647' >> /etc/sysctl.d/99-custom.conf",
            "echo 'fs.inotify.max_user_watches=524288' >> /etc/sysctl.d/99-custom.conf",
            "echo 'kernel.unprivileged_userns_clone=1' >> /etc/sysctl.d/99-custom.conf",
            "sysctl -p /etc/sysctl.d/99-custom.conf || true"
        ]
        for cmd in commands:
            try:
                await execute_lxc(container_name, f"exec {container_name} -- bash -c \"{cmd}\"", node_id=node_id)
            except Exception as e:
                logger.warning(f"Internal initialization script block output error inside {container_name}: {e}")
        logger.info(f"Internal container privilege optimizations applied inside {container_name}")
    except Exception as e:
        logger.error(f"Failed inside payload script routing execution for {container_name}: {e}")

async def get_or_create_vps_role(guild: discord.Guild) -> Optional[discord.Role]:
    global VPS_USER_ROLE_ID
    me = guild.me
    if not me or not me.guild_permissions.manage_roles:
        return None
    role_name = f"{BOT_NAME} VPS User"
    if VPS_USER_ROLE_ID:
        role = guild.get_role(VPS_USER_ROLE_ID)
        if role and role < me.top_role:
            return role
    role = discord.utils.get(guild.roles, name=role_name)
    if role:
        if role >= me.top_role:
            try:
                await role.delete(reason="Recreating role because of order restrictions.")
            except discord.Forbidden:
                return None
            role = None
        else:
            VPS_USER_ROLE_ID = role.id
            return role
    try:
        role = await guild.create_role(
            name=role_name,
            color=discord.Color.dark_purple(),
            permissions=discord.Permissions.none(),
            reason="HyperCloud VPS customer representation"
        )
        await role.edit(position=me.top_role.position - 1)
        VPS_USER_ROLE_ID = role.id
        return role
    except Exception as e:
        logger.error(f"Failed to provision Discord role {role_name}: {e}")
        return None

# Resource Statistics Parsers
def get_host_cpu_usage() -> float:
    try:
        if shutil.which("mpstat"):
            res = subprocess.run(['mpstat', '1', '1'], capture_output=True, text=True)
            for line in res.stdout.split('\n'):
                if 'all' in line and '%' in line:
                    return 100.0 - float(line.split()[-1])
        else:
            res = subprocess.run(['top', '-bn1'], capture_output=True, text=True)
            for line in res.stdout.split('\n'):
                if '%Cpu(s):' in line:
                    parts = line.split()
                    return 100.0 - float(parts[7])
        return 0.0
    except Exception as e:
        logger.error(f"Error parsing host CPU metrics: {e}")
        return 0.0

def get_host_ram_usage() -> float:
    try:
        res = subprocess.run(['free', '-m'], capture_output=True, text=True)
        lines = res.stdout.splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            total = int(parts[1])
            used = int(parts[2])
            return (used / total * 100) if total > 0 else 0.0
        return 0.0
    except Exception as e:
        logger.error(f"Error parsing host RAM metrics: {e}")
        return 0.0

def get_host_disk_usage() -> str:
    try:
        res = subprocess.run(['df', '-h', '/'], capture_output=True, text=True)
        lines = res.stdout.splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            return f"{parts[2]}/{parts[1]} ({parts[4]})"
        return "Unknown"
    except Exception as e:
        logger.error(f"Error parsing host storage values: {e}")
        return "Unknown"

async def get_host_stats(node_id: int) -> Dict[str, Any]:
    node = get_node(node_id)
    if not node:
        return {"cpu": 0.0, "ram": 0.0, "disk": "Unknown"}
    if node['is_local']:
        return {
            "cpu": get_host_cpu_usage(),
            "ram": get_host_ram_usage(),
            "disk": get_host_disk_usage()
        }
    else:
        url = f"{node['url']}/api/get_host_stats"
        params = {"api_key": node["api_key"]}
        try:
            loop = asyncio.get_running_loop()
            res = await loop.run_in_executor(
                None,
                lambda: requests.get(url, params=params, timeout=10)
            )
            res.raise_for_status()
            stats = res.json()
            stats['disk'] = stats.get('disk', 'Unknown')
            return stats
        except Exception as e:
            logger.error(f"Failed fetching specs from distributed host node '{node['name']}': {e}")
            return {"cpu": 0.0, "ram": 0.0, "disk": "Unknown"}

async def get_container_stats(container_name: str, node_id: Optional[int] = None) -> Dict[str, Any]:
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    node = get_node(node_id)
    if not node:
        return {"status": "unknown", "cpu": 0.0, "ram": {"used": 0, "total": 0, "pct": 0.0}, "disk": "Unknown", "uptime": "Unknown"}
    
    if node['is_local']:
        try:
            status = "stopped"
            p = await asyncio.create_subprocess_exec("lxc", "info", container_name, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            out, _ = await p.communicate()
            for line in out.decode(errors='replace').splitlines():
                if line.startswith("Status: "):
                    status = line.split(": ", 1)[1].strip().lower()
            
            cpu = 0.0
            ram = {"used": 0, "total": 0, "pct": 0.0}
            disk = "Unknown"
            uptime = "Unknown"
            
            if status == "running":
                p_top = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "top", "-bn1", stdout=asyncio.subprocess.PIPE)
                out_top, _ = await p_top.communicate()
                for line in out_top.decode(errors='replace').splitlines():
                    if '%Cpu(s):' in line:
                        parts = line.split()
                        cpu = 100.0 - float(parts[7])
                
                p_free = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "free", "-m", stdout=asyncio.subprocess.PIPE)
                out_free, _ = await p_free.communicate()
                lines = out_free.decode(errors='replace').splitlines()
                if len(lines) > 1:
                    parts = lines[1].split()
                    tot = int(parts[1])
                    usd = int(parts[2])
                    pct = (usd / tot * 100) if tot > 0 else 0.0
                    ram = {"used": usd, "total": tot, "pct": pct}
                
                p_df = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "df", "-h", "/", stdout=asyncio.subprocess.PIPE)
                out_df, _ = await p_df.communicate()
                for line in out_df.decode(errors='replace').splitlines():
                    if '/dev/' in line or 'root' in line or ' /' in line:
                        parts = line.split()
                        if len(parts) >= 5:
                            disk = f"{parts[2]}/{parts[1]} ({parts[4]})"
                
                p_up = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "uptime", stdout=asyncio.subprocess.PIPE)
                out_up, _ = await p_up.communicate()
                uptime = out_up.decode(errors='replace').strip()
                
            return {"status": status, "cpu": cpu, "ram": ram, "disk": disk, "uptime": uptime}
        except Exception:
            return {"status": "stopped", "cpu": 0.0, "ram": {"used": 0, "total": 0, "pct": 0.0}, "disk": "Unknown", "uptime": "Unknown"}
    else:
        url = f"{node['url']}/api/get_container_stats"
        payload = {"container": container_name}
        params = {"api_key": node["api_key"]}
        try:
            loop = asyncio.get_running_loop()
            res = await loop.run_in_executor(
                None,
                lambda: requests.post(url, json=payload, params=params, timeout=10)
            )
            res.raise_for_status()
            return res.json()
        except Exception:
            return {"status": "unknown", "cpu": 0.0, "ram": {"used": 0, "total": 0, "pct": 0.0}, "disk": "Unknown", "uptime": "Unknown"}

# Periodic monitoring background thread
resource_monitor_active = True

def resource_monitor():
    global resource_monitor_active
    last_db_backup = time.time()
    while resource_monitor_active:
        try:
            # Metrics diagnostic run
            nodes = get_nodes()
            for n in nodes:
                try:
                    stats = asyncio.run(get_host_stats(n['id']))
                    cpu, ram = stats.get('cpu', 0.0), stats.get('ram', 0.0)
                    logger.info(f"Node Resource Diagnostics [ID: {n['id']} | Name: {n['name']}]: CPU={cpu:.1f}%, RAM={ram:.1f}%")
                    if cpu > CPU_THRESHOLD or ram > RAM_THRESHOLD:
                        logger.warning(f"THRESHOLD EXCEEDED: Node {n['name']} resources (CPU: {cpu:.1f}%, RAM: {ram:.1f}%) crossed limits (CPU: {CPU_THRESHOLD}%, RAM: {RAM_THRESHOLD}%).")
                except Exception as e:
                    logger.error(f"Resource diagnostic thread node failure (Node ID: {n['id']}): {e}")
            
            # Database backups rotation
            if time.time() - last_db_backup > 14400: # 4 hours rotation
                backup_name = f"vps_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                try:
                    shutil.copy('vps.db', backup_name)
                    if os.path.exists('vps.db-wal'):
                        shutil.copy('vps.db-wal', f"{backup_name}-wal")
                    logger.info(f"Database automated snapshot successfully rotated to: {backup_name}")
                    last_db_backup = time.time()
                except Exception as e:
                    logger.error(f"Automated DB rotation failed: {e}")
            
            time.sleep(60)
        except Exception as e:
            logger.error(f"Core runtime diagnostics failure: {e}")
            time.sleep(60)

# Instantiate resource analytics thread
monitor_thread = threading.Thread(target=resource_monitor, daemon=True)
monitor_thread.start()

# Bot Setup
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# Formatting Utility Handlers
def truncate_text(text: str, max_length: int = 1024) -> str:
    if not text:
        return text
    return text[:max_length-3] + "..." if len(text) > max_length else text

def create_embed(title: str, description: str = "", color: int = 0x1a1a1a) -> discord.Embed:
    emb = discord.Embed(
        title=truncate_text(f"🌟 {BOT_NAME} - {title}", 256),
        description=truncate_text(description, 4096),
        color=color
    )
    emb.set_thumbnail(url="https://cdn.discordapp.com/attachments/1476927503191904256/1482685889246396478/Untitled_design__2_-removebg-preview.png")
    emb.set_footer(
        text=f"{BOT_NAME} VPS Engine v{BOT_VERSION} • {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        icon_url="https://cdn.discordapp.com/attachments/1476927503191904256/1482685889246396478/Untitled_design__2_-removebg-preview.png"
    )
    return emb

def add_field(emb: discord.Embed, name: str, value: str, inline: bool = False) -> discord.Embed:
    emb.add_field(name=truncate_text(f"▸ {name}", 256), value=truncate_text(value, 1024), inline=inline)
    return emb

def create_success_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(title, description, color=0x00ff88)

def create_error_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(title, description, color=0xff3366)

def create_info_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(title, description, color=0x00ccff)

def create_warning_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(title, description, color=0xffaa00)

# Security and check decorators
def is_admin():
    async def predicate(ctx):
        uid = str(ctx.author.id)
        if uid == str(MAIN_ADMIN_ID) or uid in admin_data.get('admins', []):
            return True
        raise commands.CheckFailure("Permission restriction: Administrator clearance required.")
    return commands.check(predicate)

def is_main_admin():
    async def predicate(ctx):
        if str(ctx.author.id) == str(MAIN_ADMIN_ID):
            return True
        raise commands.CheckFailure("Permission restriction: Primary Developer / Main Owner clearance required.")
    return commands.check(predicate)

# Core Bot Events
@bot.event
async def on_ready():
    logger.info(f"{bot.user} integrated and registered globally with Discord!")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f"{BOT_NAME} VPS Core"))
    
    loaded_commands = len(bot.commands)
    loaded_cogs = len(bot.cogs)
    
    print(f"✓ Loaded Commands: {loaded_commands}")
    print(f"✓ Loaded Cogs: {loaded_cogs}")
    logger.info(f"Loaded Commands: {loaded_commands}")
    logger.info(f"Loaded Cogs: {loaded_cogs}")
    
    try:
        # Global sync
        synced_global = await bot.tree.sync()
        print("✓ Slash Commands Synced")
        print("✓ Global Sync Completed")
        logger.info(f"Global sync completed: {len(synced_global)} commands synced.")
        
        # Guild sync for testing
        guilds_synced = 0
        for guild in bot.guilds:
            try:
                bot.tree.copy_global_to(guild=guild)
                await bot.tree.sync(guild=guild)
                guilds_synced += 1
            except Exception as ge:
                logger.warning(f"Could not instant sync to guild {guild.id}: {ge}")
        
        print("✓ Guild Sync Completed")
        logger.info(f"Guild sync completed across {guilds_synced} guilds.")
        
    except Exception as e:
        logger.error(f"Failed to sync slash commands: {e}", exc_info=e)
        print(f"❌ Failed to sync slash commands: {e}")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingPermissions) or isinstance(error, commands.CheckFailure):
        await ctx.send(embed=create_error_embed("Missing Permission", "❌ You don't have permission to use this command."))
    elif isinstance(error, commands.MissingRequiredArgument):
        sig = f" `{PREFIX}{ctx.command.name} {ctx.command.signature}`" if ctx.command else ""
        await ctx.send(embed=create_error_embed("Invalid Arguments", f"❌ Invalid arguments.\n\nUsage:{sig}"))
    elif isinstance(error, commands.BadArgument):
        await ctx.send(embed=create_error_embed("Invalid Arguments", f"❌ Invalid arguments formatting. Check parameter types."))
    else:
        # Save Python traceback
        import traceback
        os.makedirs('logs', exist_ok=True)
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        log_file = f"logs/err_{timestamp}.log"
        try:
            with open(log_file, 'w', encoding='utf-8') as f:
                traceback.print_exception(type(error), error, error.__traceback__, file=f)
        except Exception:
            pass
        
        logger.error(f"Unmanaged Runtime Exception: {error}", exc_info=error)
        await ctx.send(embed=create_error_embed("Internal Error", "⚠️ Internal server error.\n\nDevelopers have been notified."))

# System Diagnostic Commands
@bot.hybrid_command(name='sync')
@is_admin()
@app_commands.describe(scope="The scope of the sync (global, guild, current)")
async def sync_tree(ctx, scope: str = "current"):
    scope = scope.lower().strip()
    if scope not in ["global", "guild", "current"]:
        await ctx.send(embed=create_error_embed("Invalid Sync Scope", "Scope must be either `global`, `guild`, or `current`."))
        return
        
    await ctx.send(embed=create_info_embed("Syncing Commands", f"Initiating command tree synchronization for scope `{scope}`..."))
    
    try:
        if scope == "global":
            synced = await bot.tree.sync()
            await ctx.send(embed=create_success_embed("Global Sync Completed", f"Successfully synced `{len(synced)}` global slash commands."))
        elif scope == "guild":
            synced_count = 0
            for g in bot.guilds:
                try:
                    bot.tree.copy_global_to(guild=g)
                    await bot.tree.sync(guild=g)
                    synced_count += 1
                except Exception as ge:
                    logger.warning(f"Could not sync guild {g.id}: {ge}")
            await ctx.send(embed=create_success_embed("Guild Sync Completed", f"Successfully synced command tree to `{synced_count}` guilds."))
        else: # current
            if ctx.guild:
                bot.tree.copy_global_to(guild=ctx.guild)
                synced = await bot.tree.sync(guild=ctx.guild)
                await ctx.send(embed=create_success_embed("Current Guild Sync Completed", f"Successfully synced `{len(synced)}` commands to current guild `{ctx.guild.name}`."))
            else:
                await ctx.send(embed=create_error_embed("Guild Context Required", "Current guild sync can only be executed within a Discord server."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Sync Failed", f"An error occurred during command tree synchronization: {e}"))

@bot.hybrid_command(name='ping')
async def ping(ctx):
    lat = round(bot.latency * 1000)
    await ctx.send(embed=create_success_embed("Pong!", f"Connection gateway latency: {lat}ms"))

@bot.hybrid_command(name='uptime')
async def uptime(ctx):
    try:
        res = subprocess.run(['uptime'], capture_output=True, text=True)
        up = res.stdout.strip()
    except Exception:
        up = "Unknown Host Uptime"
    await ctx.send(embed=create_info_embed("Host Operational Metrics", up))

@bot.hybrid_command(name='thresholds')
@is_admin()
async def thresholds(ctx):
    await ctx.send(embed=create_info_embed("Suspension Guard Thresholds", f"**CPU Limit:** {CPU_THRESHOLD}%\n**RAM Limit:** {RAM_THRESHOLD}%"))

@bot.hybrid_command(name='set-threshold')
@is_admin()
async def set_threshold(ctx, cpu: int, ram: int):
    global CPU_THRESHOLD, RAM_THRESHOLD
    if cpu <= 0 or ram <= 0:
        await ctx.send(embed=create_error_embed("Invalid Setup Values", "Resource thresholds must be positive values."))
        return
    CPU_THRESHOLD, RAM_THRESHOLD = cpu, ram
    set_setting('cpu_threshold', str(cpu))
    set_setting('ram_threshold', str(ram))
    await ctx.send(embed=create_success_embed("Threshold Profiles Refreshed", f"**CPU Ceiling:** {cpu}%\n**RAM Ceiling:** {ram}%"))

@bot.hybrid_command(name='set-status')
@is_admin()
async def set_status(ctx, activity_type: str, *, name: str):
    types = {
        'playing': discord.ActivityType.playing,
        'watching': discord.ActivityType.watching,
        'listening': discord.ActivityType.listening,
        'streaming': discord.ActivityType.streaming
    }
    if activity_type.lower() not in types:
        await ctx.send(embed=create_error_embed("Error", "Valid categories: playing, watching, listening, streaming"))
        return
    await bot.change_presence(activity=discord.Activity(type=types[activity_type.lower()], name=name))
    await ctx.send(embed=create_success_embed("Gateway Profile Refreshed", f"Updated status to {activity_type}: {name}"))

# VPS Interactive Creation Wizard
class NodeSelectView(discord.ui.View):
    def __init__(self, ram: int, cpu: int, disk: int, user: discord.Member, ctx):
        super().__init__(timeout=300)
        self.ram, self.cpu, self.disk = ram, cpu, disk
        self.user, self.ctx = user, ctx
        nodes = get_nodes()
        opts = []
        for n in nodes:
            curr = get_current_vps_count(n['id'])
            if curr < n['total_vps']:
                opts.append(discord.SelectOption(label=n['name'], value=str(n['id']), description=f"Region: {n['location']} - Limit Available: {n['total_vps'] - curr}"))
        if not opts:
            self.add_item(discord.ui.Select(placeholder="No available deployment slots", disabled=True))
        else:
            self.select = discord.ui.Select(placeholder="Select Host Node", options=opts)
            self.select.callback = self.node_callback
            self.add_item(self.select)

    async def node_callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(embed=create_error_embed("Unauthorized Command Access"), ephemeral=True)
            return
        node_id = int(self.select.values[0])
        self.select.disabled = True
        await interaction.response.edit_message(view=self)
        view = OSSelectView(self.ram, self.cpu, self.disk, self.user, self.ctx, node_id)
        await interaction.followup.send(embed=create_info_embed("System Profiles Directory", "Select target OS architecture template:"), view=view)

class OSSelectView(discord.ui.View):
    def __init__(self, ram: int, cpu: int, disk: int, user: discord.Member, ctx, node_id: int):
        super().__init__(timeout=300)
        self.ram, self.cpu, self.disk = ram, cpu, disk
        self.user, self.ctx, self.node_id = user, ctx, node_id
        opts = [discord.SelectOption(label=o['label'], value=o['value']) for o in OS_OPTIONS]
        self.select = discord.ui.Select(placeholder="Select Operating System Profile", options=opts)
        self.select.callback = self.os_callback
        self.add_item(self.select)

    async def os_callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(embed=create_error_embed("Unauthorized Command Access"), ephemeral=True)
            return
        os_v = self.select.values[0]
        self.select.disabled = True
        
        # Create progressive steps embed
        def get_progress_embed(step_index, error_msg=None):
            steps = [
                "Preparing VPS...",
                "Installing packages...",
                "Creating user...",
                "Configuring firewall...",
                "Finished."
            ]
            emb = create_info_embed("VPS Deployment Pipeline")
            desc = ""
            for i, step in enumerate(steps):
                if i < step_index:
                    desc += f"✅ **{step}**\n"
                elif i == step_index:
                    if error_msg:
                        desc += f"❌ **{step}** (Failed: {error_msg})\n"
                    else:
                        desc += f"⏳ **{step}** (In Progress...)\n"
                else:
                    desc += f"⚪ {step}\n"
            emb.description = desc
            return emb

        await interaction.response.edit_message(embed=get_progress_embed(0), view=self)
        
        uid = str(self.user.id)
        if uid not in vps_data:
            vps_data[uid] = []
        vps_idx = len(vps_data[uid]) + 1
        container_name = f"{BOT_NAME.lower()}-vps-{uid}-{vps_idx}"
        ram_mb = self.ram * 1024
        
        log_system_event("deployment", f"Starting deployment of '{container_name}' (OS: {os_v}, RAM: {self.ram}GB, CPU: {self.cpu}, Disk: {self.disk}GB) on Node {self.node_id}")
        
        try:
            # Step 0: Preparing VPS (initializing & setting limits)
            await execute_lxc(container_name, f"init {os_v} {container_name} -s {DEFAULT_STORAGE_POOL}", node_id=self.node_id)
            await execute_lxc(container_name, f"config set {container_name} limits.memory {ram_mb}MB", node_id=self.node_id)
            await execute_lxc(container_name, f"config set {container_name} limits.cpu {self.cpu}", node_id=self.node_id)
            await execute_lxc(container_name, f"config device set {container_name} root size={self.disk}GB", node_id=self.node_id)
            await apply_lxc_config(container_name, self.node_id)
            await execute_lxc(container_name, f"start {container_name}", node_id=self.node_id)
            
            # Step 1: Installing packages (tmate, etc)
            await interaction.edit_original_response(embed=get_progress_embed(1), view=self)
            try:
                await execute_lxc(container_name, f"exec {container_name} -- apt-get update -y", node_id=self.node_id)
                await execute_lxc(container_name, f"exec {container_name} -- apt-get install -y openssh-server tmate sudo curl net-tools iproute2 ufw", node_id=self.node_id)
            except Exception as pe:
                log_system_event("deployment", f"Warning: Package pre-installation had issues: {pe}", "warning")
            
            # Step 2: Creating user
            await interaction.edit_original_response(embed=get_progress_embed(2), view=self)
            username = f"client_{uid[:5]}"
            password = "".join(random.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=12))
            try:
                await execute_lxc(container_name, f"exec {container_name} -- useradd -m -s /bin/bash -g sudo {username}", node_id=self.node_id)
                await execute_lxc(container_name, f"exec {container_name} -- bash -c \"echo '{username}:{password}' | chpasswd\"", node_id=self.node_id)
            except Exception as ue:
                log_system_event("deployment", f"Warning: User creation had issues or user already exists: {ue}", "warning")
            
            # Step 3: Configuring firewall
            await interaction.edit_original_response(embed=get_progress_embed(3), view=self)
            await apply_internal_permissions(container_name, self.node_id)
            try:
                # Basic UFW setup inside container if supported
                await execute_lxc(container_name, f"exec {container_name} -- ufw default allow outgoing", node_id=self.node_id)
                await execute_lxc(container_name, f"exec {container_name} -- ufw default deny incoming", node_id=self.node_id)
                await execute_lxc(container_name, f"exec {container_name} -- ufw allow 22/tcp", node_id=self.node_id)
                await execute_lxc(container_name, f"exec {container_name} -- ufw --force enable", node_id=self.node_id)
            except Exception as fe:
                log_system_event("deployment", f"Warning: Firewall rules application had issues: {fe}", "warning")
            
            # Step 4: Finished
            await interaction.edit_original_response(embed=get_progress_embed(4), view=self)
            
            vps_info = {
                "container_name": container_name,
                "node_id": self.node_id,
                "ram": f"{self.ram}GB",
                "cpu": str(self.cpu),
                "storage": f"{self.disk}GB",
                "config": f"{self.ram}GB RAM / {self.cpu} CPU / {self.disk}GB Storage",
                "os_version": os_v,
                "status": "running",
                "suspended": False,
                "whitelisted": False,
                "suspension_history": [],
                "created_at": datetime.now().isoformat(),
                "shared_with": [],
                "id": None
            }
            vps_data[uid].append(vps_info)
            save_vps_data()
            
            if self.ctx.guild:
                role = await get_or_create_vps_role(self.ctx.guild)
                if role:
                    try:
                        await self.user.add_roles(role, reason="Granted VPS client profile access.")
                    except Exception:
                        pass
                        
            success_emb = create_success_embed("VPS Successfully Provisioned")
            add_field(success_emb, "User Profile Link", self.user.mention, True)
            add_field(success_emb, "Machine Reference", f"`{container_name}`", True)
            add_field(success_emb, "LXD Micro-architect Node", get_node(self.node_id)['name'], True)
            add_field(success_emb, "Allocated Profiles Specs", f"**RAM allocation:** {self.ram}GB\n**CPU cores:** {self.cpu} Cores\n**Storage allocation:** {self.disk}GB", False)
            add_field(success_emb, "Operating System OS", os_v, True)
            add_field(success_emb, "Default SSH Credentials", f"**User:** `{username}`\n**Password:** `{password}`", False)
            add_field(success_emb, "Diagnostic File System Note", "Run command: `sudo resize2fs /` inside VPS shell if necessary to extend file system boundaries.", False)
            await interaction.followup.send(embed=success_emb)
            
            # DM user credentials
            try:
                dm = create_success_embed("VPS Virtual Systems Activated")
                add_field(dm, "Virtual Hardware Specs", f"**Machine ID:** `{container_name}`\n**Profile Spec:** {self.ram}GB RAM / {self.cpu} CPU Cores / {self.disk}GB Storage\n**OS Target Image:** {os_v}", False)
                add_field(dm, "Default SSH Credentials", f"**SSH Username:** `{username}`\n**SSH Password:** `{password}`", False)
                add_field(dm, "Diagnostic Interface Gateway", f"• Launch diagnostics panel: `{PREFIX}manage` in server channels\n• Setup network port forwarding mappings: `{PREFIX}ports` in server channels", False)
                await self.user.send(embed=dm)
            except Exception:
                pass
                
            log_system_event("deployment", f"Deployment of '{container_name}' completed successfully.")
        except Exception as e:
            await interaction.edit_original_response(embed=get_progress_embed(0, error_msg=str(e)), view=self)
            await interaction.followup.send(embed=create_error_embed("Deployment Pipelines Failure", f"Virtualization failed: {e}"))
            log_system_event("deployment", f"Deployment of '{container_name}' failed: {e}", "error", e)

def parse_ram(val: str) -> Optional[int]:
    """
    Parses RAM input and returns an integer in GB.
    Returns None if parsing fails.
    """
    val = str(val).strip().upper()
    if not val:
        return None
    
    # Check if ends with GB
    if val.endswith('GB'):
        try:
            num = float(val[:-2].strip())
            return int(num)
        except ValueError:
            return None
    # Check if ends with MB
    if val.endswith('MB'):
        try:
            num = float(val[:-2].strip())
            return max(1, int(num / 1024))
        except ValueError:
            return None
    # Check if ends with G
    if val.endswith('G'):
        try:
            num = float(val[:-1].strip())
            return int(num)
        except ValueError:
            return None
    # Check if ends with M
    if val.endswith('M'):
        try:
            num = float(val[:-1].strip())
            return max(1, int(num / 1024))
        except ValueError:
            return None
            
    # Pure numeric
    try:
        num = float(val)
        # If the number is 128 or less, we assume it's GB
        if num <= 128:
            return int(num)
        else:
            # Otherwise, assume it's MB and convert to GB
            return max(1, int(num / 1024))
    except ValueError:
        return None

def parse_cpu(val: str) -> Optional[int]:
    """
    Parses CPU input and returns an integer representing cores.
    Returns None if parsing fails.
    """
    val = str(val).strip()
    try:
        num = float(val)
        # Check if it is a whole number
        if num.is_integer():
            return int(num)
        return None
    except ValueError:
        return None

def parse_disk(val: str) -> Optional[int]:
    """
    Parses Disk input and returns an integer in GB.
    Returns None if parsing fails.
    """
    val = str(val).strip().upper()
    if not val:
        return None
    
    # Check if ends with GB
    if val.endswith('GB'):
        try:
            num = float(val[:-2].strip())
            return int(num)
        except ValueError:
            return None
    # Check if ends with MB
    if val.endswith('MB'):
        try:
            num = float(val[:-2].strip())
            return max(1, int(num / 1024))
        except ValueError:
            return None
    # Check if ends with G
    if val.endswith('G'):
        try:
            num = float(val[:-1].strip())
            return int(num)
        except ValueError:
            return None
    # Check if ends with M
    if val.endswith('M'):
        try:
            num = float(val[:-1].strip())
            return max(1, int(num / 1024))
        except ValueError:
            return None
            
    # Pure numeric
    try:
        num = float(val)
        # If the number is > 2000, we assume it's MB, otherwise GB
        if num > 2000:
            return max(1, int(num / 1024))
        else:
            return int(num)
    except ValueError:
        return None

async def parse_member(ctx, val: str) -> Optional[discord.Member]:
    """
    Parses User input (Mention, User ID, Username) and returns discord.Member.
    Returns None if member not found.
    """
    if not val:
        return None
    val = str(val).strip()
    
    # Try custom ID/Mention parsing first
    cleaned_id = val
    if val.startswith('<@') and val.endswith('>'):
        cleaned_id = val[2:-1]
        if cleaned_id.startswith('!'):
            cleaned_id = cleaned_id[1:]
    if cleaned_id.isdigit():
        uid = int(cleaned_id)
        if ctx.guild:
            member = ctx.guild.get_member(uid)
            if member:
                return member
            try:
                member = await ctx.guild.fetch_member(uid)
                return member
            except Exception:
                pass
                
    # Fallback to MemberConverter
    try:
        converter = commands.MemberConverter()
        member = await converter.convert(ctx, val)
        return member
    except Exception:
        pass
        
    return None

@bot.hybrid_command(name='createvps', aliases=['create', 'create-vps'])
@is_admin()
@app_commands.describe(
    ram="RAM allocation (e.g., 1GB, 1024MB, 1024, 2048)",
    cpu="CPU cores allocation (e.g., 1, 2, 4)",
    disk="Storage allocation (e.g., 10GB, 10240MB, 10)",
    user="Target user (Mention, User ID, or Username)"
)
async def create_vps(ctx, ram: str, cpu: str, disk: str, user: str):
    # Field-specific validation lists
    errors = []
    
    # 1. Parse RAM
    parsed_ram = parse_ram(ram)
    if parsed_ram is None:
        errors.append("❌ **Invalid RAM**: Value could not be parsed. Acceptable formats: `1GB`, `1024MB`, `2048`, `1024`")
    elif parsed_ram < 1 or parsed_ram > 128:
        errors.append(f"❌ **Invalid RAM**: Parsed as `{parsed_ram}GB`. Value must be between 1GB and 128GB.")
        
    # 2. Parse CPU
    parsed_cpu = parse_cpu(cpu)
    if parsed_cpu is None:
        errors.append("❌ **Invalid CPU**: Value must be an integer (e.g., `1`, `2`, `4`).")
    elif parsed_cpu < 1 or parsed_cpu > 64:
        errors.append(f"❌ **Invalid CPU**: Parsed as `{parsed_cpu}` core(s). Value must be between 1 and 64 cores.")
        
    # 3. Parse Disk
    parsed_disk = parse_disk(disk)
    if parsed_disk is None:
        errors.append("❌ **Invalid Disk**: Value could not be parsed. Acceptable formats: `10GB`, `10240MB`, `10`")
    elif parsed_disk < 5 or parsed_disk > 2000:
        errors.append(f"❌ **Invalid Disk**: Parsed as `{parsed_disk}GB`. Value must be between 5GB and 2000GB.")
        
    # 4. Parse User
    parsed_user = await parse_member(ctx, user)
    if parsed_user is None:
        errors.append("❌ **Invalid User**: Could not locate or resolve the specified user. Acceptable formats: Mention, User ID, or Username.")

    # Debug logs
    log_system_event("createvps_debug", f"Parsed RAM: {parsed_ram}GB, Parsed CPU: {parsed_cpu}, Parsed Disk: {parsed_disk}GB, Parsed User: {parsed_user}")

    # If errors exist, return them together
    if errors:
        emb = create_error_embed("Validation Failed")
        emb.description = "\n".join(errors)
        await ctx.send(embed=emb)
        return
        
    nodes = get_nodes()
    if not nodes:
        await ctx.send(embed=create_error_embed("Infrastructure Error", "❌ No cluster nodes are configured or available."))
        return
        
    # Check if any node has slot available
    available_nodes = [n for n in nodes if get_current_vps_count(n['id']) < n['total_vps']]
    if not available_nodes:
        await ctx.send(embed=create_error_embed("Infrastructure Saturated", "❌ All nodes are at maximum container capacity."))
        return

    # Everything is successfully validated, deploy starts
    view = NodeSelectView(parsed_ram, parsed_cpu, parsed_disk, parsed_user, ctx)
    await ctx.send(embed=create_info_embed("Deployment Provisioning Wizard", "Please select target host Node for this deployment instance below:"), view=view)

# Dashboard Operations Control Manager
class ReinstallOSSelectView(discord.ui.View):
    def __init__(self, parent_view, container_name: str, owner_id: str, actual_idx: int, ram: int, cpu: int, disk: int, node_id: int):
        super().__init__(timeout=300)
        self.parent_view, self.container_name = parent_view, container_name
        self.owner_id, self.actual_idx = owner_id, actual_idx
        self.ram, self.cpu, self.disk, self.node_id = ram, cpu, disk, node_id
        opts = [discord.SelectOption(label=o['label'], value=o['value']) for o in OS_OPTIONS]
        self.select = discord.ui.Select(placeholder="Select Reinstallation OS", options=opts)
        self.select.callback = self.reinstall_callback
        self.add_item(self.select)

    async def reinstall_callback(self, interaction: discord.Interaction):
        os_v = self.select.values[0]
        self.select.disabled = True
        await interaction.response.edit_message(embed=create_info_embed("Reinstallation Lifecycle Activated", "Formatting root virtual boundary systems and loading OS distributions files..."), view=self)
        ram_mb = self.ram * 1024
        try:
            await execute_lxc(self.container_name, f"init {os_v} {self.container_name} -s {DEFAULT_STORAGE_POOL}", node_id=self.node_id)
            await execute_lxc(self.container_name, f"config set {self.container_name} limits.memory {ram_mb}MB", node_id=self.node_id)
            await execute_lxc(self.container_name, f"config set {self.container_name} limits.cpu {self.cpu}", node_id=self.node_id)
            await execute_lxc(self.container_name, f"config device set {self.container_name} root size={self.disk}GB", node_id=self.node_id)
            await apply_lxc_config(self.container_name, self.node_id)
            await execute_lxc(self.container_name, f"start {self.container_name}", node_id=self.node_id)
            await apply_internal_permissions(self.container_name, self.node_id)
            await recreate_port_forwards(self.container_name)
            
            tgt = vps_data[self.owner_id][self.actual_idx]
            tgt['os_version'] = os_v
            tgt['status'] = 'running'
            tgt['suspended'] = False
            tgt['created_at'] = datetime.now().isoformat()
            tgt['config'] = f"{self.ram}GB RAM / {self.cpu} CPU / {self.disk}GB Storage"
            save_vps_data()
            
            await interaction.followup.send(embed=create_success_embed("Reinstallation Lifecycle Succeeded", f"Virtual Machine Container `{self.container_name}` formatted and loaded with `{os_v}` specifications successfully."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Reinstallation Pipelines Aborted", f"Error: {e}"), ephemeral=True)

class ManageView(discord.ui.View):
    def __init__(self, user_id: str, vps_list: List[Dict[str, Any]], is_shared=False, owner_id=None, is_admin=False, actual_index: Optional[int] = None):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.vps_list = vps_list[:]
        self.selected_index = None
        self.is_shared = is_shared
        self.owner_id = owner_id or user_id
        self.is_admin = is_admin
        self.actual_index = actual_index
        self.indices = list(range(len(vps_list)))
        
        if len(vps_list) > 1:
            opts = [discord.SelectOption(label=f"VPS Instance #{i+1} ({v['container_name']})", value=str(i), description=f"Host specifications: {v.get('config', 'Specs profile unlisted')}") for i, v in enumerate(vps_list)]
            self.select = discord.ui.Select(placeholder="Select Virtual Machine instance to access dashboard...", options=opts)
            self.select.callback = self.select_vps_callback
            self.add_item(self.select)
        else:
            self.selected_index = 0
            self.add_control_actions()

    def add_control_actions(self):
        if not self.is_shared and not self.is_admin:
            reinst = discord.ui.Button(label="Format / Reinstall OS", style=discord.ButtonStyle.danger, emoji="🔄")
            reinst.callback = lambda inter: self.action_router(inter, 'reinstall')
            self.add_item(reinst)
        
        start = discord.ui.Button(label="Power Start", style=discord.ButtonStyle.success, emoji="▶")
        start.callback = lambda inter: self.action_router(inter, 'start')
        
        stop = discord.ui.Button(label="Power Shutdown", style=discord.ButtonStyle.secondary, emoji="⏸")
        stop.callback = lambda inter: self.action_router(inter, 'stop')
        
        ssh = discord.ui.Button(label="Establish SSH Tunnel", style=discord.ButtonStyle.primary, emoji="🔑")
        ssh.callback = lambda inter: self.action_router(inter, 'ssh')
        
        stats = discord.ui.Button(label="Live Hardware Metrics", style=discord.ButtonStyle.secondary, emoji="📊")
        stats.callback = lambda inter: self.action_router(inter, 'stats')
        
        self.add_item(start)
        self.add_item(stop)
        self.add_item(ssh)
        self.add_item(stats)

    async def select_vps_callback(self, interaction: discord.Interaction):
        if interaction.user.id != int(self.user_id) and not self.is_admin:
            await interaction.response.send_message(embed=create_error_embed("Unauthorized Command Access"), ephemeral=True)
            return
        self.selected_index = int(self.select.values[0])
        self.clear_items()
        self.add_control_actions()
        emb = await self.create_metrics_embed(self.selected_index)
        await interaction.response.edit_message(embed=emb, view=self)

    async def create_metrics_embed(self, idx: int) -> discord.Embed:
        v = self.vps_list[idx]
        node = get_node(v['node_id'])
        node_name = node['name'] if node else "Unknown Node"
        status = v.get('status', 'stopped')
        suspended = v.get('suspended', False)
        whitelisted = v.get('whitelisted', False)
        
        col = 0x00ff88 if status == 'running' and not suspended else 0xffaa00 if suspended else 0xff3366
        emb = create_embed(f"System Control Dashboard [Node: {node_name}]", f"Device boundary name: `{v['container_name']}`", col)
        
        stats = await get_container_stats(v['container_name'], node_id=v['node_id'])
        metrics_text = (
            f"**Container Status:** `{stats['status'].upper()}`\n"
            f"**Ceiling Memory Allocation:** {v['ram']}\n"
            f"**Ceiling CPU Processing Limit:** {v['cpu']} Core(s)\n"
            f"**Ceiling Disk Volume Size:** {v['storage']}\n"
            f"**Base Image Kernel profile:** {v.get('os_version', 'ubuntu:22.04')}\n"
            f"**Uptime duration:** {stats['uptime']}"
        )
        add_field(emb, "Allocated Profiles Configurations", metrics_text, False)
        
        if suspended:
            add_field(emb, "🛑 SUSPENSION WARNING", "This Virtual Machine is restricted due to security protocols or resource ceiling violations.", False)
        if whitelisted:
            add_field(emb, "🛡️ CEILING BYPASS ACTIVED", "This virtual hardware container is whitelisted from automated ceiling limitations checking.", False)
            
        real_time_usage = (
            f"**Real-time CPU Consumption:** {stats['cpu']:.1f}%\n"
            f"**Real-time RAM Usage:** {stats['ram']['used']}/{stats['ram']['total']} MB ({stats['ram']['pct']:.1f}%)\n"
            f"**Storage Allocated Bound Usage:** {stats['disk']}"
        )
        add_field(emb, "Real-time Live Resource Usage Metrics", real_time_usage, False)
        return emb

    async def action_router(self, interaction: discord.Interaction, action: str):
        if interaction.user.id != int(self.user_id) and not self.is_admin:
            await interaction.response.send_message(embed=create_error_embed("Unauthorized Command Access"), ephemeral=True)
            return
        if self.selected_index is None:
            await interaction.response.send_message(embed=create_error_embed("Hardware Selection Violation", "Identify active instance from dropdown first."), ephemeral=True)
            return
        
        real_idx = self.actual_index if self.is_shared else self.indices[self.selected_index]
        tgt = vps_data[self.owner_id][real_idx]
        suspended = tgt.get('suspended', False)
        
        if suspended and not self.is_admin and action != 'stats':
            await interaction.response.send_message(embed=create_error_embed("Access Blocked", "All virtual infrastructure operations are restricted on suspended hardware containers. Contact server admins."), ephemeral=True)
            return
        
        container = tgt['container_name']
        node_id = tgt['node_id']
        
        if action == 'stats':
            stats = await get_container_stats(container, node_id)
            emb = create_info_embed("📈 Real-time Diagnostic Data", f"Statistics for `{container}`:")
            add_field(emb, "LXC State", stats['status'].upper(), True)
            add_field(emb, "CPU Consumption", f"{stats['cpu']:.1f}%", True)
            add_field(emb, "RAM Memory Consumption", f"{stats['ram']['used']}/{stats['ram']['total']} MB ({stats['ram']['pct']:.1f}%)", True)
            add_field(emb, "Boundary Disk Storage Consumption", stats['disk'], True)
            add_field(emb, "Device Operational Uptime", stats['uptime'], True)
            await interaction.response.send_message(embed=emb, ephemeral=True)
            return
            
        if action == 'reinstall':
            ram = int(tgt['ram'].replace('GB', ''))
            cpu = int(tgt['cpu'])
            disk = int(tgt['storage'].replace('GB', ''))
            
            confirm_emb = create_warning_embed("⚠️ ROOT FILE SYSTEM FORMAT RESTRICTION WARNING", f"Format sequence will erase ALL existing configuration data, scripts, files, and users inside `{container}` permanently.\n\nContinue with re-initialization deployment?")
            
            class FormatConfirmationView(discord.ui.View):
                def __init__(self, parent, container_name, owner, r_gb, cpu_c, d_gb, nid, idx):
                    super().__init__(timeout=60)
                    self.parent = parent
                    self.container_name = container_name
                    self.owner_id = owner_id
                    self.idx = idx
                    self.ram_gb = r_gb
                    self.cpu = cpu
                    self.disk_gb = d_gb
                    self.node_id = node_id

                @discord.ui.button(label="Destructive Format Confirm", style=discord.ButtonStyle.danger)
                async def delete_and_reinstall(self, inter: discord.Interaction, item: discord.ui.Button):
                    await inter.response.defer(ephemeral=True)
                    try:
                        await inter.followup.send(embed=create_info_embed("Format Sequence Initiated", f"Terminating virtualization and purging image boundaries on `{self.container_name}`..."), ephemeral=True)
                        await execute_lxc(self.container_name, f"delete {self.container_name} --force", node_id=self.node_id)
                        view = ReinstallOSSelectView(self.parent, self.container_name, self.owner_id, self.idx, self.ram_gb, self.cpu, self.disk_gb, self.node_id)
                        await inter.followup.send(embed=create_info_embed("Purge Complete", "Select target OS distribution profile to re-deploy:"), view=view, ephemeral=True)
                    except Exception as e:
                        await inter.followup.send(embed=create_error_embed("Teardown Fail", f"Error: {e}"), ephemeral=True)

                @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
                async def cancel_run(self, inter: discord.Interaction, item: discord.ui.Button):
                    await inter.response.edit_message(embed=create_info_embed("Diagnostics Operational Run Cleared", "Destructive operations sequence aborted cleanly."), view=None)

            await interaction.response.send_message(embed=confirm_emb, view=FormatConfirmationView(self, container, self.owner_id, ram, cpu, disk, node_id, real_idx), ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        if action == 'start':
            try:
                await execute_lxc(container, f"start {container}", node_id=node_id)
                tgt['status'] = 'running'
                save_vps_data()
                await apply_internal_permissions(container, node_id)
                readd_ct = await recreate_port_forwards(container)
                await interaction.followup.send(embed=create_success_embed("Virtual System Power Activation Run Success", f"Hardware container initialized cleanly and launched. Reallocated {readd_ct} active hardware port mappings."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Power Start Exception", f"Error: {e}"), ephemeral=True)
        elif action == 'stop':
            try:
                await execute_lxc(container, f"stop {container} --force", node_id=node_id)
                tgt['status'] = 'stopped'
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Power Sequence Execution Succeeded", "LXC hypervisor completed device halt sequence successfully."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Halt Pipeline Failure", f"Error: {e}"), ephemeral=True)
        elif action == 'ssh':
            try:
                # Check for tmate availability inside container
                try:
                    await execute_lxc(container, f"exec {container} -- which tmate", node_id=node_id)
                except Exception:
                    await interaction.followup.send(embed=create_info_embed("Security Tunnel Agent Missing", "Installing secure `tmate` routing package inside virtual instance..."), ephemeral=True)
                    await execute_lxc(container, f"exec {container} -- apt-get update -y", node_id=node_id)
                    await execute_lxc(container, f"exec {container} -- apt-get install tmate -y", node_id=node_id)
                    await interaction.followup.send(embed=create_success_embed("Tunneling Agent Package Resolved", "Routing scripts successfully updated inside container."), ephemeral=True)
                
                ses_id = f"{BOT_NAME.lower()}-ssh-{datetime.now().strftime('%Y%m%d%H%M%S')}"
                await execute_lxc(container, f"exec {container} -- tmate -S /tmp/{ses_id}.sock new-session -d", node_id=node_id)
                await asyncio.sleep(4)
                ssh_out = await execute_lxc(container, f"exec {container} -- tmate -S /tmp/{ses_id}.sock display -p '#{{tmate_ssh}}'", node_id=node_id)
                tunnel_url = ssh_out.strip()
                
                if tunnel_url:
                    try:
                        tun_emb = create_success_embed("SSH Operational Session Tunnel Created")
                        add_field(tun_emb, "Establish CLI Session Shell Command", f"```{tunnel_url}```", False)
                        add_field(tun_emb, "🔑 Session Security Constraint", "This virtual tunneling session is isolated and temporary. Do NOT share this routing line with third parties.", False)
                        await interaction.user.send(embed=tun_emb)
                        await interaction.followup.send(embed=create_success_embed("Security Session Gateway Tunnel Active", "SSH routing pipeline established. Credentials dispatched directly via user DM channels."), ephemeral=True)
                    except discord.Forbidden:
                        await interaction.followup.send(embed=create_error_embed("Security Session Gateway Failure", "Discord user DM dispatch failed. Check your Privacy settings to allow developer dispatch."), ephemeral=True)
                else:
                    await interaction.followup.send(embed=create_error_embed("Tunneling Agent Processing Exception", "Gateway daemon returned failure sequence when establishing shell proxy."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Operational Session Core Error", f"Transmission exception: {e}"), ephemeral=True)
                
        emb = await self.create_metrics_embed(self.selected_index)
        await interaction.edit_original_response(embed=emb, view=self)

@bot.hybrid_command(name='manage')
async def manage_vps(ctx, user: discord.Member = None):
    if user:
        uid = str(ctx.author.id)
        if uid != str(MAIN_ADMIN_ID) and uid not in admin_data.get('admins', []):
            await ctx.send(embed=create_error_embed("Security Access Violation", "Clearance diagnostics check: Administrator privileges required."))
            return
        target_uid = str(user.id)
        lst = vps_data.get(target_uid, [])
        if not lst:
            await ctx.send(embed=create_error_embed("Database Query Failure", f"No active virtual boundaries registered under {user.mention} profile."))
            return
        view = ManageView(str(ctx.author.id), lst, is_admin=True, owner_id=target_uid)
        emb = await view.get_initial_embed() if hasattr(view, 'get_initial_embed') else await view.create_metrics_embed(0)
        await ctx.send(embed=emb, view=view)
    else:
        uid = str(ctx.author.id)
        lst = vps_data.get(uid, [])
        if not lst:
            await ctx.send(embed=create_error_embed("Hardware Profile Diagnostic Fault", f"You do not possess any active virtual server deployment on {BOT_NAME} clusters. Submit deployment form to system administrators."))
            return
        view = ManageView(uid, lst)
        emb = await view.get_initial_embed() if hasattr(view, 'get_initial_embed') else await view.create_metrics_embed(0)
        await ctx.send(embed=emb, view=view)

# Diagnostics Panel Visualizers
@bot.hybrid_command(name="myvps")
async def my_vps(ctx):
    uid = str(ctx.author.id)
    lst = vps_data.get(uid, [])
    if not lst:
        await ctx.send(embed=create_error_embed("Zero Deployments Registered", "No virtual server resources mapped under your discord signature."))
        return
    emb = create_info_embed("Operational Infrastructure Status Panel", "Active virtual devices status summaries:")
    for i, v in enumerate(lst, 1):
        node = get_node(v['node_id'])
        node_name = node['name'] if node else "Diagnostic Cluster Node"
        status = "🟢 ACTIVE" if v.get('status') == 'running' and not v.get('suspended') else "⛔ SUSPENDED" if v.get('suspended') else "🔴 POWER_OFF"
        specs = f"Specs: {v['ram']} Memory | {v['cpu']} Core(s) CPU | {v['storage']} Disk volume boundaries\nHypervisor Target: `{node_name}`"
        add_field(emb, f"Deployment #{i} - Machine: {v['container_name']}", f"Status: `{status}`\n{specs}", False)
    await ctx.send(embed=emb)

@bot.hybrid_command(name='restart', aliases=['restartvps', 'restart-vps'])
async def restart_vps_cmd(ctx, vps_number: int = None):
    uid = str(ctx.author.id)
    lst = vps_data.get(uid, [])
    if not lst:
        await ctx.send(embed=create_error_embed("Zero Deployments Registered", "No virtual server resources mapped under your discord signature."))
        return
    if vps_number is None:
        if len(lst) == 1:
            vps_number = 1
        else:
            await ctx.send(embed=create_error_embed("Multiple Instances Found", f"You have multiple VPS. Please specify the index, e.g., `{PREFIX}restart 1`"))
            return
    if vps_number < 1 or vps_number > len(lst):
        await ctx.send(embed=create_error_embed("Invalid Index", f"Target device index is invalid. Use a number between 1 and {len(lst)}."))
        return
    
    v = lst[vps_number - 1]
    container = v['container_name']
    node_id = v['node_id']
    
    if v.get('suspended'):
        await ctx.send(embed=create_error_embed("Access Blocked", "This Virtual Machine is suspended and cannot be restarted. Contact admins."))
        return
        
    await ctx.send(embed=create_info_embed("Restarting VPS", f"Executing power restart sequence on container `{container}`..."))
    try:
        await execute_lxc(container, f"stop {container} --force", node_id=node_id)
        await execute_lxc(container, f"start {container}", node_id=node_id)
        v['status'] = 'running'
        save_vps_data()
        await apply_internal_permissions(container, node_id)
        readd_ct = await recreate_port_forwards(container)
        await ctx.send(embed=create_success_embed("VPS Restarted", f"Successfully restarted `{container}` and restored {readd_ct} active port forwards."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Restart Failed", f"Error during restart sequence: {e}"))

@bot.hybrid_command(name='reload')
@is_admin()
async def reload_command(ctx):
    try:
        reload_caches()
        await ctx.send(embed=create_success_embed("Caches Reloaded", "Successfully synchronized memory caches with the SQLite database."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Reload Failed", f"Error while synchronizing database: {e}"))

@bot.hybrid_command(name='shutdown', aliases=['stop-bot', 'shutdown-bot'])
@is_main_admin()
async def shutdown_bot_cmd(ctx):
    await ctx.send(embed=create_success_embed("Shutdown Sequence Activated", "The bot is shutting down gracefully..."))
    graceful_halt()
    await bot.close()

@bot.hybrid_command(name='list-all')
@is_admin()
async def list_all_vps(ctx):
    total_ct = 0
    running_ct = 0
    vps_desc = []
    for uid, lst in vps_data.items():
        total_ct += len(lst)
        for v in lst:
            status = "running"
            if v.get('suspended'):
                status = "suspended"
            elif v.get('status') == 'stopped':
                status = "stopped"
            if status == "running":
                running_ct += 1
            node = get_node(v['node_id'])
            n_name = node['name'] if node else "Unregistered Node"
            vps_desc.append(f"• `{v['container_name']}` | Owner: <@{uid}> | OS: {v.get('os_version', 'N/A')} | State: `{status.upper()}` | Node: `{n_name}`")
    
    emb = create_info_embed("Global Virtual Infrastructure System Report", f"**Active deployments configuration mapped count:** {total_ct} instances\n**Active running LXC virtual engines:** {running_ct} running clusters")
    desc_txt = "\n".join(vps_desc) if vps_desc else "No active virtual boundaries deployed."
    
    chunks = [desc_txt[i:i+1024] for i in range(0, len(desc_txt), 1024)]
    for i, chunk in enumerate(chunks, 1):
        add_field(emb, f"Virtual Boundary Matrix (Page {i})", chunk, False)
    await ctx.send(embed=emb)

@bot.hybrid_command(name='deletevps', aliases=['delete', 'delete-vps', 'delete_vps'])
@is_admin()
async def delete_vps(ctx, user: discord.Member, vps_number: int, *, reason: str = "Administrator Lifecycle Maintenance"):
    uid = str(user.id)
    if uid not in vps_data or vps_number < 1 or vps_number > len(vps_data[uid]):
        await ctx.send(embed=create_error_embed("Hardware Profile Diagnostic Fault", "Hardware reference target index is invalid or nonexistent."))
        return
        
    tgt = vps_data[uid][vps_number - 1]
    container = tgt['container_name']
    node_id = tgt.get('node_id', 1)
    
    await ctx.send(embed=create_info_embed("Infrastructure Teardown In Progress", f"Triggering hard purge routine on container database mappings and storage arrays for `{container}`..."))
    
    try:
        await execute_lxc(container, f"delete {container} --force", node_id=node_id)
        node_status = "LXC container storage maps purged successfully."
    except Exception as e:
        node_status = f"LXC hypervisor returned cleanup warning: {e}"
        
    with get_db() as conn:
        conn.execute('DELETE FROM vps WHERE container_name = ?', (container,))
        conn.execute('DELETE FROM port_forwards WHERE vps_container = ?', (container,))
        conn.commit()
        
    del vps_data[uid][vps_number - 1]
    if not vps_data[uid]:
        del vps_data[uid]
        if ctx.guild:
            role = await get_or_create_vps_role(ctx.guild)
            if role and role in user.roles:
                try:
                    await user.remove_roles(role)
                except Exception:
                    pass
                    
    save_vps_data()
    
    emb = create_success_embed("Virtual Infrastructure Teardown Pipeline Complete")
    add_field(emb, "Previous Owner Key", user.mention, True)
    add_field(emb, "Purged Machine ID", f"`{container}`", True)
    add_field(emb, "LXC Hypervisor Routine Status", node_status, False)
    add_field(emb, "Cleanup Protocol Context Code", reason, False)
    await ctx.send(embed=emb)

# Bandwidth limits and network interfaces
@bot.hybrid_command(name='vps-network')
@is_admin()
async def vps_network(ctx, container_name: str, action: str, value: str = None):
    node_id = find_node_id_for_container(container_name)
    act = action.lower()
    if act not in ["list", "add", "remove", "limit"]:
        await ctx.send(embed=create_error_embed("Input Validation Fault", f"Usage syntax parameter error. Options: `{PREFIX}vps-network <container> <list|add|remove|limit> [value]`"))
        return
    try:
        if act == "list":
            out = await execute_lxc(container_name, f"exec {container_name} -- ip addr", node_id=node_id)
            emb = create_info_embed(f"Network Diagnostics Output - {container_name}")
            add_field(emb, "LXC Interface Array Maps", f"```\n{out[:1000]}\n```", False)
            await ctx.send(embed=emb)
        elif act == "limit" and value:
            await execute_lxc(container_name, f"config device set {container_name} eth0 limits.egress {value}", node_id=node_id)
            await execute_lxc(container_name, f"config device set {container_name} eth0 limits.ingress {value}", node_id=node_id)
            await ctx.send(embed=create_success_embed("Bandwidth Metrics Bound Updated", f"Consolidated traffic boundaries on ethernet device eth0 set to `{value}` inside `{container_name}`."))
        elif act == "add" and value:
            await execute_lxc(container_name, f"config device add {container_name} eth1 nic nictype=bridged parent={value}", node_id=node_id)
            await ctx.send(embed=create_success_embed("Network Interface Device Mounted", f"Added virtual ethernet bridging device `eth1` mapped directly to parent interface `{value}` inside `{container_name}`."))
        elif act == "remove" and value:
            await execute_lxc(container_name, f"config device remove {container_name} {value}", node_id=node_id)
            await ctx.send(embed=create_success_embed("Network Interface Purged", f"Dismounted network equipment dev node `{value}` successfully from `{container_name}` hardware configuration."))
        else:
            await ctx.send(embed=create_error_embed("Validation Error", "Invalid interface equipment values or actions payload specified."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Network Management Fault", f"LXC equipment interface returned error: {e}"))

# Process Diagnostic Commands
@bot.hybrid_command(name='vps-processes')
@is_admin()
async def vps_processes(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    try:
        out = await execute_lxc(container_name, f"exec {container_name} -- ps aux", node_id=node_id)
        emb = create_info_embed(f"Container Operational Processes Diagnostics - {container_name}")
        chunks = [out[i:i+1000] for i in range(0, len(out), 1000)]
        for idx, chunk in enumerate(chunks[:3], 1): # Cap logging report at 3 diagnostic chunks to prevent overflow
            add_field(emb, f"Diagnostic Logging Frame #{idx}", f"```\n{chunk}\n```", False)
        await ctx.send(embed=emb)
    except Exception as e:
        await ctx.send(embed=create_error_embed("Processes Diagnostics Fault", f"Error: {e}"))

@bot.hybrid_command(name='vps-logs')
@is_admin()
async def vps_logs(ctx, container_name: str, lines: int = 40):
    node_id = find_node_id_for_container(container_name)
    try:
        out = await execute_lxc(container_name, f"exec {container_name} -- journalctl -n {lines} --no-pager", node_id=node_id)
        emb = create_info_embed(f"System Systemd Diagnostic Journalctl Report - {container_name}")
        chunks = [out[i:i+1000] for i in range(0, len(out), 1000)]
        for idx, chunk in enumerate(chunks[:3], 1):
            add_field(emb, f"Log Output Chunk #{idx}", f"```\n{chunk}\n```", False)
        await ctx.send(embed=emb)
    except Exception as e:
        await ctx.send(embed=create_error_embed("Log Retrieval Exceptions Fault", f"Error: {e}"))

# Dynamic resources management
@bot.hybrid_command(name='resize-vps')
@is_admin()
async def resize_vps(ctx, container_name: str, ram: int = None, cpu: int = None, disk: int = None):
    if ram is None and cpu is None and disk is None:
        await ctx.send(embed=create_error_embed("Validation Missing Data", "At least one specification metric (RAM, CPU cores, Disk size) must be targeted for re-allocation."))
        return
    uid = None
    v_idx = None
    for owner_id, lst in vps_data.items():
        for i, v in enumerate(lst):
            if v['container_name'] == container_name:
                uid, v_idx = owner_id, i
                break
        if uid:
            break
    if uid is None or v_idx is None:
        await ctx.send(embed=create_error_embed("Database Query Fault", "Could not locate container record inside cluster tables."))
        return
    
    tgt = vps_data[uid][v_idx]
    node_id = tgt['node_id']
    was_active = tgt.get('status') == 'running' and not tgt.get('suspended')
    
    if was_active:
        await ctx.send(embed=create_info_embed("Hot Swap Warning Restriction", f"Halt system routine active. Shunting operational state of `{container_name}` to reconfigure hardware metrics profiles safely..."))
        await execute_lxc(container_name, f"stop {container_name} --force", node_id=node_id)
        tgt['status'] = 'stopped'
        save_vps_data()
        
    changes = []
    try:
        curr_ram = int(tgt['ram'].replace('GB', ''))
        curr_cpu = int(tgt['cpu'])
        curr_disk = int(tgt['storage'].replace('GB', ''))
        
        new_ram = ram if ram else curr_ram
        new_cpu = cpu if cpu else curr_cpu
        new_disk = disk if disk else curr_disk
        
        if ram:
            await execute_lxc(container_name, f"config set {container_name} limits.memory {new_ram * 1024}MB", node_id=node_id)
            changes.append(f"Ceiling Memory Allocation updated: **{new_ram}GB**")
        if cpu:
            await execute_lxc(container_name, f"config set {container_name} limits.cpu {new_cpu}", node_id=node_id)
            changes.append(f"Ceiling CPU processing allocation updated: **{new_cpu} Cores**")
        if disk:
            await execute_lxc(container_name, f"config device set {container_name} root size={new_disk}GB", node_id=node_id)
            changes.append(f"Root Volume Storage Limit updated: **{new_disk}GB**")
            
        tgt['ram'] = f"{new_ram}GB"
        tgt['cpu'] = str(new_cpu)
        tgt['storage'] = f"{new_disk}GB"
        tgt['config'] = f"{new_ram}GB RAM / {new_cpu} CPU / {new_disk}GB Storage"
        save_vps_data()
        
        if was_active:
            await execute_lxc(container_name, f"start {container_name}", node_id=node_id)
            tgt['status'] = 'running'
            save_vps_data()
            await apply_internal_permissions(container_name, node_id)
            await recreate_port_forwards(container_name)
            
        emb = create_success_embed("Virtual Specs Scalability Sequence Success")
        add_field(emb, "Re-allocation Metric Updates", "\n".join(changes), False)
        await ctx.send(embed=emb)
    except Exception as e:
        await ctx.send(embed=create_error_embed("Dynamic Scaling Allocation Fault", f"Error encountered scaling LXC parameters: {e}"))

# Snapshots operations
@bot.hybrid_command(name='snapshot')
@is_admin()
async def snapshot_vps(ctx, container_name: str, snap_name: str = "snap0"):
    node_id = find_node_id_for_container(container_name)
    await ctx.send(embed=create_info_embed("Snapshot Compilation Sequence Initiated", f"Exporting container structural systems image state '{snap_name}' on `{container_name}`..."))
    try:
        await execute_lxc(container_name, f"snapshot {container_name} {snap_name}", node_id=node_id)
        await ctx.send(embed=create_success_embed("Snapshot Compiled Successfully", f"State system image '{snap_name}' successfully committed to host storage for container `{container_name}`."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Snapshot Image Creation Failure", f"Error: {e}"))

@bot.hybrid_command(name='list-snapshots')
@is_admin()
async def list_snapshots(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    try:
        out = await execute_lxc(container_name, f"snapshot list {container_name}", node_id=node_id)
        emb = create_info_embed(f"Cluster Snapshots Directory Indexes - {container_name}")
        add_field(emb, "Committed Container State Images", f"```\n{out}\n```", False)
        await ctx.send(embed=emb)
    except Exception as e:
        await ctx.send(embed=create_error_embed("Snapshot System Query Fail", f"Error: {e}"))

@bot.hybrid_command(name='restore-snapshot')
@is_admin()
async def restore_snapshot(ctx, container_name: str, snap_name: str):
    node_id = find_node_id_for_container(container_name)
    warn = create_warning_embed("⚠️ SNAPSHOT ROLLBACK DESTRUCTIVE WARNING", f"Rolling system configuration back to image '{snap_name}' will permanently discard and overwrite all active configuration updates inside `{container_name}`.\n\nExecute destructive rollback sequence?")
    
    class RollbackConfirmation(discord.ui.View):
        def __init__(self, c_name, s_name, nid):
            super().__init__(timeout=60)
            self.c_name, self.s_name, self.nid = c_name, s_name, nid

        @discord.ui.button(label="Execute Rollback Pipeline", style=discord.ButtonStyle.danger)
        async def confirm_rollback(self, inter: discord.Interaction, item: discord.ui.Button):
            await inter.response.defer()
            try:
                await execute_lxc(self.c_name, f"stop {self.c_name} --force", node_id=self.nid)
                await execute_lxc(self.c_name, f"restore {self.c_name} {self.s_name}", node_id=self.nid)
                await execute_lxc(self.c_name, f"start {self.c_name}", node_id=self.nid)
                await apply_internal_permissions(self.c_name, self.nid)
                await recreate_port_forwards(self.c_name)
                
                # Sync cache
                for uid, lst in vps_data.items():
                    for v in lst:
                        if v['container_name'] == self.c_name:
                            v['status'] = 'running'
                            v['suspended'] = False
                save_vps_data()
                await inter.followup.send(embed=create_success_embed("Hypervisor Rollback Run Success", f"Rollback successfully updated target virtual systems to '{self.s_name}' image on `{self.c_name}`."))
            except Exception as e:
                await inter.followup.send(embed=create_error_embed("Rollback Fail", f"Error: {e}"))

        @discord.ui.button(label="Abort Action", style=discord.ButtonStyle.secondary)
        async def cancel_action(self, inter: discord.Interaction, item: discord.ui.Button):
            await inter.response.edit_message(embed=create_info_embed("Rollback Pipelines Aborted", "Diagnostic recovery operation cleared cleanly."), view=None)

    await ctx.send(embed=warn, view=RollbackConfirmation(container_name, snap_name, node_id))

# Admin whitelist/blacklist, suspend protocols
@bot.hybrid_command(name='suspend-vps')
@is_admin()
async def suspend_vps(ctx, container_name: str, *, reason: str = "Admin restriction protocol activity"):
    node_id = find_node_id_for_container(container_name)
    found = False
    for uid, lst in vps_data.items():
        for v in lst:
            if v['container_name'] == container_name:
                found = True
                if v.get('status') != 'running':
                    await ctx.send(embed=create_error_embed("Invalid Device State", "Container must be actively powered on to execute suspension shunting protocols."))
                    return
                try:
                    await execute_lxc(container_name, f"stop {container_name} --force", node_id=node_id)
                    v['status'] = 'stopped'
                    v['suspended'] = True
                    v['suspension_history'].append({
                        "time": datetime.now().isoformat(),
                        "reason": reason,
                        "by": f"{ctx.author.name} (ID: {ctx.author.id})"
                    })
                    save_vps_data()
                    await ctx.send(embed=create_success_embed("Hardware Suspension Pipeline Succeeded", f"Shunted device operational boundaries on `{container_name}` successfully."))
                    
                    # DM Owner
                    try:
                        owner = await bot.fetch_user(int(uid))
                        dm = create_warning_embed("⚠️ INFRASTRUCTURE SUSPENSION PROTOCOL ACTIVATED", f"Your Virtual server instance `{container_name}` was suspended by system administrators.\n\n**Violation Protocol context:** {reason}\n\nSubmit appeal request inside support channels to lift hardware container suspension.")
                        await owner.send(embed=dm)
                    except Exception:
                        pass
                except Exception as e:
                    await ctx.send(embed=create_error_embed("Suspension Execution Fault", f"Error: {e}"))
                break
        if found:
            break
    if not found:
        await ctx.send(embed=create_error_embed("Database Query Fault", "Could not locate matching virtual container boundary reference."))

@bot.hybrid_command(name='unsuspend-vps')
@is_admin()
async def unsuspend_vps(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    found = False
    for uid, lst in vps_data.items():
        for v in lst:
            if v['container_name'] == container_name:
                found = True
                if not v.get('suspended', False):
                    await ctx.send(embed=create_error_embed("Unnecessary Pipeline Route", "This container hardware instance is not currently flagged under suspension protocols."))
                    return
                try:
                    v['suspended'] = False
                    await execute_lxc(container_name, f"start {container_name}", node_id=node_id)
                    v['status'] = 'running'
                    await apply_internal_permissions(container_name, node_id)
                    await recreate_port_forwards(container_name)
                    save_vps_data()
                    await ctx.send(embed=create_success_embed("Operational Un-suspension Complete", f"Restored network gateway routes and power profiles cleanly for `{container_name}`."))
                    
                    try:
                        owner = await bot.fetch_user(int(uid))
                        dm = create_success_embed("🟢 Virtual Infrastructure Restored", f"Suspension protocols lifted on device container `{container_name}`. Your virtual systems and mapped ports are operational.")
                        await owner.send(embed=dm)
                    except Exception:
                        pass
                except Exception as e:
                    await ctx.send(embed=create_error_embed("LXC Recovery Activation Fail", f"Error: {e}"))
                break
        if found:
            break
    if not found:
        await ctx.send(embed=create_error_embed("Database Query Fault", "Device container record not mapped inside node database files."))

@bot.hybrid_command(name='whitelist-vps')
@is_admin()
async def whitelist_vps(ctx, container_name: str, action: str):
    act = action.lower()
    if act not in ['add', 'remove']:
        await ctx.send(embed=create_error_embed("Input Validation Fault", f"Usage parameter error. Correct options: `{PREFIX}whitelist-vps <container> <add|remove>`"))
        return
    found = False
    for uid, lst in vps_data.items():
        for v in lst:
            if v['container_name'] == container_name:
                found = True
                v['whitelisted'] = (act == 'add')
                save_vps_data()
                status_txt = "registered as bypassed from ceiling resources checks" if act == 'add' else "returned to automated resource monitor constraints"
                await ctx.send(embed=create_success_embed("Monitoring Whitelist Profile Matrix Refreshed", f"Container hardware instance `{container_name}` status: {status_txt}."))
                break
        if found:
            break
    if not found:
        await ctx.send(embed=create_error_embed("Database Query Fault", "Could not locate virtual container specification in database."))

# User statistics & infrastructure health
@bot.hybrid_command(name='userinfo', aliases=['user-info', 'user_info'])
@is_admin()
async def user_info(ctx, user: discord.Member):
    try:
        uid = str(user.id)
        lst = vps_data.get(uid, [])
        emb = create_info_embed(f"User Resource Overview - {user.name}", f"Checking allocation details for {user.mention}")
        add_field(emb, "Identity", f"**ID:** {user.id}\n**Joined Discord:** {user.joined_at.strftime('%Y-%m-%d') if user.joined_at else 'Unknown'}", True)
        
        is_adm = uid == str(MAIN_ADMIN_ID) or uid in admin_data.get('admins', [])
        add_field(emb, "Privileges", f"**Is Administrator:** {'Yes ✅' if is_adm else 'No ❌'}", True)
        
        ports_all = get_user_allocation(uid)
        ports_u = get_user_used_ports(uid)
        add_field(emb, "Network Interfaces", f"**Port Mapping Limits:** {ports_u}/{ports_all} Slots used", True)
        
        if lst:
            ram_sum, cpu_sum, storage_sum = 0, 0, 0
            vps_desc = []
            for i, v in enumerate(lst, 1):
                try:
                    ram_sum += int(v['ram'].replace('GB', ''))
                    cpu_sum += int(v['cpu'])
                    storage_sum += int(v['storage'].replace('GB', ''))
                except Exception:
                    pass
                state = "🟢 RUNNING" if v.get('status') == 'running' and not v.get('suspended') else "⛔ SUSPENDED" if v.get('suspended') else "🔴 POWER_OFF"
                vps_desc.append(f"**#{i} `{v['container_name']}`:** OS: {v.get('os_version', 'Unknown')} | State: {state}")
            
            totals = f"**CPU Allocation:** {cpu_sum} Cores\n**RAM Allocation:** {ram_sum}GB\n**Disk Boundaries Allocation:** {storage_sum}GB"
            add_field(emb, "Hardware Totals", totals, False)
            add_field(emb, "Active Allocations List", "\n".join(vps_desc), False)
        else:
            add_field(emb, "Deployment Profiles Mapped", "No active virtual boundaries registered under profile.", False)
            
        await ctx.send(embed=emb)
    except Exception as e:
        log_system_event("runtime_errors", "Error executing userinfo command", "error", e)
        await ctx.send(embed=create_error_embed("Internal Error", "⚠️ An error occurred while running the userinfo command."))

@bot.hybrid_command(name='serverstats')
@is_admin()
async def server_stats(ctx):
    vps_count = sum(len(lst) for lst in vps_data.values())
    tot_ram, tot_cpu, tot_disk = 0, 0, 0
    active, suspended, stopped = 0, 0, 0
    
    for lst in vps_data.values():
        for v in lst:
            try:
                tot_ram += int(v['ram'].replace('GB', ''))
                tot_cpu += int(v['cpu'])
                tot_disk += int(v['storage'].replace('GB', ''))
            except Exception:
                pass
            if v.get('suspended'):
                suspended += 1
            elif v.get('status') == 'running':
                active += 1
            else:
                stopped += 1
                
    emb = create_info_embed("HyperCloud Virtual Clusters Core Statistics")
    add_field(emb, "Global Demographics Summary", f"**Registered Clients Count:** {len(vps_data)}\n**Total Container Deployments count:** {vps_count}", True)
    add_field(emb, "Operating State Metrics Matrix", f"**Active Engines running:** {active} 🟢\n**Halted Engines stopped:** {stopped} 🔴\n**Suspended Engines restricted:** {suspended} 🟡", True)
    add_field(emb, "Aggine Hardware Allocations", f"**Consolidated CPU Allocation:** {tot_cpu} Core(s)\n**Consolidated RAM Allocation:** {tot_ram}GB\n**Consolidated Disk Boundary Allocation:** {tot_disk}GB", False)
    await ctx.send(embed=emb)

@bot.hybrid_command(name='status', aliases=['systemstatus', 'system-status', 'system_status', 'nodes'])
@is_admin()
async def system_status(ctx):
    start = time.time()
    nodes = get_nodes()
    
    active_n = 0
    offline_n = 0
    node_desc = []
    
    for n in nodes:
        if n['is_local']:
            active_n += 1
            node_desc.append(f"🖥️ **Node {n['id']} (Local - '{n['name']}')**\nRegion: {n['location']} | Status: 🟢 ONLINE")
        else:
            try:
                url = f"{n['url']}/api/ping"
                params = {"api_key": n['api_key']}
                loop = asyncio.get_running_loop()
                res = await loop.run_in_executor(
                    None,
                    lambda: requests.get(url, params=params, timeout=4)
                )
                if res.status_code == 200:
                    active_n += 1
                    node_desc.append(f"🌐 **Node {n['id']} (Remote - '{n['name']}')**\nRegion: {n['location']} | Status: 🟢 ONLINE")
                else:
                    offline_n += 1
                    node_desc.append(f"🌐 **Node {n['id']} (Remote - '{n['name']}')**\nRegion: {n['location']} | Status: 🔴 OFFLINE (API Error)")
            except Exception:
                offline_n += 1
                node_desc.append(f"🌐 **Node {n['id']} (Remote - '{n['name']}')**\nRegion: {n['location']} | Status: 🔴 OFFLINE")
                
    lat = round(bot.latency * 1000)
    proc_t = (time.time() - start) * 1000
    
    emb = create_info_embed("Complete Enterprise Cluster Diagnostics", f"Diagnostic scan executed in `{proc_t:.0f}ms`")
    add_field(emb, "Unified Services Status", f"**Bot Latency:** {lat}ms\n**Cluster nodes count:** {len(nodes)}\n**Online Node servers:** {active_n} active\n**Offline Node servers:** {offline_n} offline", False)
    add_field(emb, "Cluster Node Infrastructure Diagnostic Matrix", "\n\n".join(node_desc) if node_desc else "No nodes registered.", False)
    await ctx.send(embed=emb)

# Port-forwarding user commands
# Port-forwarding user commands
@bot.hybrid_command(name='ports')
@app_commands.describe(
    subcmd="Subcommand (add, remove, list)",
    val1="VPS number (for add) or Mapping ID (for remove)",
    val2="VPS internal port (for add)"
)
async def ports_command(ctx, subcmd: str = None, val1: str = None, val2: str = None):
    uid = str(ctx.author.id)
    alloc = get_user_allocation(uid)
    used = get_user_used_ports(uid)
    avail = alloc - used
    
    if subcmd is None:
        emb = create_info_embed("Network Equipment Port Mappings Help Panel", f"**Hardware Ports Allocations Metrics:**\n**Max Port Slots:** {alloc}\n**Used Mappings:** {used}\n**Available Free Slots:** {avail}")
        add_field(emb, "Command Arguments Syntax Directory", f"• Mount dynamic hardware mapping:\n`{PREFIX}ports add <vps_number> <vps_internal_port>`\n• Check your mapping indexes:\n`{PREFIX}ports list`\n• Dismount hardware port:\n`{PREFIX}ports remove <mapping_id>`", False)
        await ctx.send(embed=emb)
        return
        
    cmd = subcmd.lower()
    if cmd == 'add':
        if val1 is None or val2 is None:
            await ctx.send(embed=create_error_embed("Validation Error", f"Incorrect payload formatting. Correct Syntax: `{PREFIX}ports add <vps_number> <vps_internal_port>`"))
            return
        try:
            vps_num = int(val1)
            v_port = int(val2)
            if v_port < 1 or v_port > 65535:
                raise ValueError
        except ValueError:
            await ctx.send(embed=create_error_embed("Parameter Formatting Exception", "Device references and network ports must be integers (Port constraints: 1-65535)."))
            return
            
        lst = vps_data.get(uid, [])
        if vps_num < 1 or vps_num > len(lst):
            await ctx.send(embed=create_error_embed("Validation Error", "Target device reference number out of bounds."))
            return
            
        v = lst[vps_num - 1]
        container = v['container_name']
        node_id = v['node_id']
        
        if used >= alloc:
            await ctx.send(embed=create_error_embed("Port Mapping Constraints Blown", f"Your account mapping capacity ceiling ({alloc} slots) has been saturated. Appeal to server support for quota extension."))
            return
            
        await ctx.send(embed=create_info_embed("Provisioning Virtual Port Mapping Routes", "Generating random ephemeral host proxy port on node cluster..."))
        hp = await create_port_forward(uid, container, v_port, node_id)
        if hp:
            emb = create_success_embed("Network Proxy Route Mounted Successfully")
            add_field(emb, "Direct Link Routing Mapping Connection", f"`{YOUR_SERVER_IP}:{hp}` ➔ Virtual Machine Container Internal IP: `{v_port}` (TCP/UDP multiplexed)", False)
            add_field(emb, "Updated Quota Metrics Check", f"Used network slots: {used + 1}/{alloc}", False)
            await ctx.send(embed=emb)
        else:
            await ctx.send(embed=create_error_embed("Hardware Proxy Mounting Failure", "LXD hypervisor routing driver rejected binding payload request."))
            
    elif cmd == 'list':
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM port_forwards WHERE user_id = ?', (uid,))
            forwards = [dict(r) for r in cur.fetchall()]
            
        emb = create_info_embed("My active Hardware Port Mapping Configurations", f"**Current Allocation:** {used}/{alloc} slots occupied")
        if not forwards:
            add_field(emb, "Active Proxy Interfaces Mappings", "No active proxy ports configured.", False)
        else:
            txt = []
            for f in forwards:
                created = datetime.fromisoformat(f['created_at']).strftime('%Y-%m-%d %H:%M')
                txt.append(f"**Index Ref ID: `{f['id']}`** ➔ Container: `{f['vps_container']}` | Internal Port: `{f['vps_port']}` ➔ External Node Interface: `{YOUR_SERVER_IP}:{f['host_port']}` (Allocated: {created})")
            add_field(emb, "Network proxy lines mapped", "\n".join(txt), False)
        await ctx.send(embed=emb)
        
    elif cmd == 'remove':
        if val1 is None:
            await ctx.send(embed=create_error_embed("Validation Error", f"Incorrect command structure. Correct syntax: `{PREFIX}ports remove <mapping_id>`"))
            return
        try:
            fid = int(val1)
        except ValueError:
            await ctx.send(embed=create_error_embed("Parameter Type Exception", "Mapping reference IDs must be numeric values."))
            return
            
        ok, owner = await remove_port_forward(fid)
        if ok:
            await ctx.send(embed=create_success_embed("Operational Port Purge Success", f"Dismounted routing rules on mapping index ID `{fid}` cleanly."))
        else:
            await ctx.send(embed=create_error_embed("Dismount Pipeline Exception", "Target mapping ID not found inside database schema."))

# Admin allocations controls
@bot.hybrid_command(name='ports-add-user')
@is_admin()
async def ports_add_user(ctx, amount: int, user: discord.Member):
    if amount <= 0:
        await ctx.send(embed=create_error_embed("Specs Error", "Slot additions metrics must be positive numbers."))
        return
    uid = str(user.id)
    allocate_ports(uid, amount)
    tot = get_user_allocation(uid)
    await ctx.send(embed=create_success_embed("Port Mapping Slots Granted Successfully", f"Allocated additional **{amount}** slots to {user.mention}. Total boundary quota: **{tot}** slots."))

@bot.hybrid_command(name='ports-remove-user')
@is_admin()
async def ports_remove_user(ctx, amount: int, user: discord.Member):
    if amount <= 0:
        await ctx.send(embed=create_error_embed("Specs Error", "Purge values must be positive integers."))
        return
    uid = str(user.id)
    deallocate_ports(uid, amount)
    tot = get_user_allocation(uid)
    await ctx.send(embed=create_success_embed("Port Mapping Quota Boundary Decreased", f"Purged **{amount}** slots from {user.mention} resources mapping. Total boundary quota remaining: **{tot}** slots."))

# Main Owner Developer Controls
@bot.hybrid_command(name='admin-add')
@is_main_admin()
async def admin_add(ctx, user: discord.Member):
    uid = str(user.id)
    if uid in admin_data.get('admins', []):
        await ctx.send(embed=create_error_embed("Duplicate Operational Command", f"User {user.mention} already holds elevated administrator clearance profiles."))
        return
    admin_data['admins'].append(uid)
    save_admin_data()
    await ctx.send(embed=create_success_embed("Elevated Privilege Granted", f"User {user.mention} successfully registered into global administrators cluster directory."))

@bot.hybrid_command(name='admin-remove')
@is_main_admin()
async def admin_remove(ctx, user: discord.Member):
    uid = str(user.id)
    if uid not in admin_data.get('admins', []):
        await ctx.send(embed=create_error_embed("Diagnostics Exception", f"User {user.mention} does not hold administrator access clearance."))
        return
    admin_data['admins'].remove(uid)
    save_admin_data()
    await ctx.send(embed=create_success_embed("Elevated Clearance Revoked", f"Successfully removed {user.mention} credentials from access directories."))

@bot.hybrid_command(name='admin', aliases=['admin-list', 'adminlist', 'admins'])
@is_admin()
async def admin_list(ctx):
    main = await bot.fetch_user(MAIN_ADMIN_ID)
    emb = create_embed("Unified Systems Administrator Access Profiles Directory")
    add_field(emb, "👑 Main Owner Developer Key", f"{main.mention} (ID: {MAIN_ADMIN_ID})", False)
    
    adm_mentions = []
    for aid in admin_data['admins']:
        try:
            usr = await bot.fetch_user(int(aid))
            adm_mentions.append(f"• {usr.mention} (ID: {aid})")
        except Exception:
            adm_mentions.append(f"• Unresolved Identity ID: `{aid}`")
            
    add_field(emb, "🛡️ Elevate Administrator Clearances Active", "\n".join(adm_mentions) if adm_mentions else "No additional admin mappings.", False)
    await ctx.send(embed=emb)

# Automated maintenance execution scripts
@bot.hybrid_command(name='resource-check')
@is_admin()
async def resource_check(ctx):
    await ctx.send(embed=create_info_embed("Automated Threshold Scan Initiated", "Scanning active containers state resources against ceilings configuration profiles..."))
    susp_count = 0
    for uid, lst in vps_data.items():
        for v in lst:
            if v.get('status') == 'running' and not v.get('suspended') and not v.get('whitelisted'):
                container = v['container_name']
                node_id = v['node_id']
                stats = await get_container_stats(container, node_id)
                cpu = stats.get('cpu', 0.0)
                ram = stats.get('ram', {}).get('pct', 0.0)
                
                if cpu > CPU_THRESHOLD or ram > RAM_THRESHOLD:
                    reason = f"Automated Resource Guardian Suspension: Consumed resources (CPU: {cpu:.1f}%, RAM: {ram:.1f}%) crossed limits (CPU: {CPU_THRESHOLD}%, RAM: {RAM_THRESHOLD}%)."
                    try:
                        await execute_lxc(container, f"stop {container} --force", node_id=node_id)
                        v['status'] = 'stopped'
                        v['suspended'] = True
                        v['suspension_history'].append({
                            "time": datetime.now().isoformat(),
                            "reason": reason,
                            "by": "Automated Resource Monitor Agent"
                        })
                        save_vps_data()
                        susp_count += 1
                        
                        try:
                            owner = await bot.fetch_user(int(uid))
                            dm = create_warning_embed("🚨 AUTOMATED SYSTEM CEILING SHUNT INITIATED", f"Your Virtual server instance `{container}` has exceeded resource boundaries.\n\n**Diagnosis code:** {reason}\n\nAppeals are supported inside help desks.")
                            await owner.send(embed=dm)
                        except Exception:
                            pass
                    except Exception as e:
                        logger.error(f"Automated ceiling shunt failed execution run on `{container}`: {e}")
                        
    await ctx.send(embed=create_success_embed("Automated System Scan Complete", f"All container boundaries verified. Shunted operational profiles on **{susp_count}** high-usage instances successfully."))

@bot.hybrid_command(name='backup-db')
@is_admin()
async def backup_db(ctx):
    backup_name = f"vps_backup_manual_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    try:
        shutil.copy('vps.db', backup_name)
        await ctx.send(embed=create_success_embed("Database Backup Dispatched", f"Successfully exported database schema copy to: `{backup_name}`"))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Database Archiving Exception", f"Error: {e}"))

# Dynamic Cluster Nodes Deployment Controller
@bot.hybrid_command(name='node')
@is_admin()
@app_commands.describe(subcommand="The node subcommand (create or list)")
async def node_cmd(ctx, subcommand: str):
    sub = subcommand.lower()
    if sub == 'create':
        await ctx.send(embed=create_info_embed("Distributed Cluster Setup Initialized", "Enter unique identifying Name for new cluster Node server:"))
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        
        try:
            msg = await bot.wait_for('message', check=check, timeout=120)
            name = msg.content.strip()
            await ctx.send(embed=create_info_embed("Deployment Controller", "Identify operational geographic/physical Location of this Node server:"))
            msg = await bot.wait_for('message', check=check, timeout=120)
            loc = msg.content.strip()
            await ctx.send(embed=create_info_embed("Deployment Controller", "Set integer limit represent container capacity bounds on this Node:"))
            msg = await bot.wait_for('message', check=check, timeout=120)
            limit = int(msg.content.strip())
            
            await ctx.send(embed=create_info_embed("Deployment Controller", "Set node API endpoint URL (e.g., `http://10.0.0.15:5000`) or send `local` to bind on local host commands routing driver directly:"))
            msg = await bot.wait_for('message', check=check, timeout=120)
            url_in = msg.content.strip()
            
            is_local = 1 if url_in.lower() == 'local' else 0
            url = None if is_local else url_in
            api_key = None if is_local else ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=32))
            
            with get_db() as conn:
                conn.execute('INSERT INTO nodes (name, location, total_vps, tags, api_key, url, is_local) VALUES (?, ?, ?, ?, ?, ?, ?)',
                             (name, loc, limit, '[]', api_key, url, is_local))
                conn.commit()
                
            emb = create_success_embed("Distributed Cluster Node Registered successfully")
            add_field(emb, "Device Host Name", name, True)
            add_field(emb, "Target location", loc, True)
            add_field(emb, "Capacity Limits", f"{limit} VPS boundaries maximum", True)
            if not is_local:
                add_field(emb, "Security Endpoint API Passkey", f"||{api_key}||", False)
                add_field(emb, "Diagnostic Connection Endpoint API", url, False)
            await ctx.send(embed=emb)
        except Exception as e:
            await ctx.send(embed=create_error_embed("Dynamic Node Provisioning Aborted", f"Error: {e}"))
            
    elif sub == 'list':
        nodes = get_nodes()
        emb = create_info_embed("Unified Cluster Architecture Node Directory")
        for n in nodes:
            status = "Local Host Driver" if n['is_local'] else "Remote API Controller"
            details = f"**Location:** {n['location']}\n**Boundary capacity limits:** {n['total_vps']} containers max\n**Type:** {status}"
            if not n['is_local']:
                details += f"\n**Endpoint API URL:** {n['url']}"
            add_field(emb, f"Node #{n['id']} - Name: {n['name']}", details, False)
        await ctx.send(embed=emb)

# Command Documentation & Interactive Pagination Help Systems
class HelpView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
        self.current_category = "vps"
        
        self.categories_map = {
            "vps": {
                "name": "📦 VPS Commands",
                "desc": "Virtual Private Server management commands.",
                "cmds": [
                    ("createvps <ram> <cpu> <disk> @user", "Create a new VPS instance."),
                    ("deletevps @user <vps_number>", "Delete an existing VPS container."),
                    ("status", "View server/node status reports."),
                    ("myvps", "List all of your VPS instances."),
                    ("vps-logs <container>", "View container system logs."),
                    ("restart <vps_number>", "Restart a VPS instance.")
                ]
            },
            "node": {
                "name": "🖥️ Node Commands",
                "desc": "Check node statuses and physical infrastructure.",
                "cmds": [
                    ("node list", "List all configured physical nodes."),
                    ("serverstats", "View node resource utilization summaries."),
                    ("resource-check", "Run system resources diagnostics.")
                ]
            },
            "admin": {
                "name": "🛡️ Admin Commands",
                "desc": "Elevated administrator operations and maintenance.",
                "cmds": [
                    ("admin", "View administrators registry."),
                    ("reload", "Reload system caches and configurations."),
                    ("shutdown", "Power off the Discord bot client gracefully."),
                    ("sync", "Sync command tree registrations.")
                ]
            },
            "utility": {
                "name": "⚙️ Utility Commands",
                "desc": "General utility and diagnostics queries.",
                "cmds": [
                    ("ping", "Check bot latency gateway metrics."),
                    ("help", "Show this interactive command guide."),
                    ("about", "Learn details of the VPSDEPLOYBOT framework."),
                    ("uptime", "Check host server uptime duration.")
                ]
            }
        }
        
        self.add_selector()
        self.add_buttons()
        self.update_embed()

    def add_selector(self):
        opts = []
        for key, val in self.categories_map.items():
            opts.append(discord.SelectOption(label=val['name'], value=key, description=val['desc']))
        self.select = discord.ui.Select(placeholder="Select Command Category...", options=opts)
        self.select.callback = self.on_select_callback
        self.add_item(self.select)

    def add_buttons(self):
        self.add_item(discord.ui.Button(label="Support", url="https://discord.gg/vpsdeploybot", style=discord.ButtonStyle.link))
        self.add_item(discord.ui.Button(label="Documentation", url="https://docs.vpsdeploybot.com", style=discord.ButtonStyle.link))
        self.add_item(discord.ui.Button(label="Invite", url="https://discord.com/oauth2/authorize?client_id=123456&permissions=8&scope=bot", style=discord.ButtonStyle.link))

    async def on_select_callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(embed=create_error_embed("Menu Locked", "Run this help command inside your own session."), ephemeral=True)
            return
        self.current_category = self.select.values[0]
        self.update_embed()
        await interaction.response.edit_message(embed=self.embed, view=self)

    def update_embed(self):
        cat = self.categories_map[self.current_category]
        self.embed = create_embed(f"Help Directory - {cat['name']}", cat['desc'], color=0x00ccff)
        cmds_text = []
        for cmd, desc in cat['cmds']:
            cmds_text.append(f"▸ **{PREFIX}{cmd}**\n↳ _{desc}_")
        add_field(self.embed, "Commands Manual", "\n\n".join(cmds_text), False)

@bot.hybrid_command(name='help')
async def show_help(ctx):
    view = HelpView(ctx)
    emb = create_info_embed("VPSDEPLOYBOT Help Guide")
    emb.description = (
        "Welcome to the **VPSDEPLOYBOT Virtualization Control System**.\n"
        "Select a command category from the dropdown below to view specific manuals."
    )
    add_field(emb, "📂 VPS Commands", "• `h!createvps` • `h!deletevps` • `h!status` • `h!myvps` • `h!vps-logs` • `h!restart`", False)
    add_field(emb, "🖥️ Node Commands", "• `h!node list` • `h!serverstats` • `h!resource-check`", False)
    add_field(emb, "🛡️ Admin Commands", "• `h!admin` • `h!reload` • `h!shutdown` • `h!sync`", False)
    add_field(emb, "⚙️ Utility Commands", "• `h!ping` • `h!help` • `h!about` • `h!uptime`", False)
    
    await ctx.send(embed=emb, view=view)

@bot.hybrid_command(name='about')
async def about(ctx):
    vps_count = sum(len(lst) for lst in vps_data.values())
    tot_users = len(vps_data)
    lat = round(bot.latency * 1000)
    
    emb = create_info_embed("Enterprise Cloud Automation Specifications Framework")
    add_field(emb, "Core System Core Identification Details", f"**Bot Name Identifier:** {BOT_NAME}\n**Framework Software Version:** {BOT_VERSION}\n**Bot Latency Diagnostics:** {lat}ms\n**Lead Systems Developer:** {BOT_DEVELOPER}", True)
    add_field(emb, "Global Demographics Allocations", f"**Unified Virtual Containers Count:** {vps_count} machines\n**Active Virtual Registrations Clients:** {tot_users} profiles", True)
    await ctx.send(embed=emb)

# Graceful Application Teardown Handlers
def graceful_halt():
    global resource_monitor_active
    logger.info("Graceful halt sequence activated. Offlining background monitoring system hooks safely...")
    resource_monitor_active = False

def startup_checks() -> bool:
    print("=========================================")
    print("      VPSDEPLOYBOT STARTUP CHECKS        ")
    print("=========================================")
    
    ok = True
    
    # Check 1: Check .env file existence
    if not os.path.exists(".env"):
        print("[CRITICAL] .env configuration file is missing!")
        ok = False
    else:
        print("[SUCCESS] Found .env file.")
        
    # Check 2: Token verification
    if not DISCORD_TOKEN or DISCORD_TOKEN == "YOUR_DISCORD_TOKEN_HERE" or DISCORD_TOKEN == "YOUR_BOT_TOKEN":
        print("[CRITICAL] Discord Token is not configured properly in .env!")
        ok = False
    else:
        print("[SUCCESS] Discord Token found and configured.")
        
    # Check 3: Database connection
    try:
        conn = get_db()
        conn.close()
        print("[SUCCESS] SQLite Database connection verified.")
    except Exception as e:
        print(f"[CRITICAL] Database connection failed: {e}")
        ok = False
        
    # Check 4: Check directory write access and logs directory
    try:
        os.makedirs('logs', exist_ok=True)
        print("[SUCCESS] Logs directory verified and write-accessible.")
    except Exception as e:
        print(f"[CRITICAL] Failed to configure logs directory: {e}")
        ok = False
        
    # Check 5: Node data verification
    try:
        nodes = get_nodes()
        print(f"[SUCCESS] Loaded {len(nodes)} cluster nodes from database.")
    except Exception as e:
        print(f"[CRITICAL] Failed to load node parameters from database: {e}")
        ok = False
        
    print("=========================================")
    return ok

if __name__ == "__main__":
    if startup_checks():
        try:
            bot.run(DISCORD_TOKEN)
        except KeyboardInterrupt:
            graceful_halt()
        except Exception as e:
            logger.critical(f"Bot failed boot cycle pipeline: {e}")
    else:
        logger.error("SYSTEM CRITICAL FAILURE: Startup checks did not pass. Correct errors in configuration to launch bot.")
        sys.exit(1)
