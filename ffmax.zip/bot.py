#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LXC Bot V9 - Production Ready Discord Bot for LXC Cluster Management
Features fully asynchronous operation, SQLite storage (aiosqlite),
multi-node support (REST API & SSH), resource monitoring, and rich interactive views.
"""

import os
import sys
import json
import logging
import asyncio
import sqlite3
import random
import shutil
import time
from datetime import datetime
from typing import Optional, List, Dict, Any, Union

import discord
from discord import app_commands
from discord.ext import commands, tasks
import aiohttp
import aiosqlite
import psutil
import asyncssh
from dotenv import load_dotenv

# Load Environment Variables
load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
GUILD_ID_STR = os.getenv("GUILD_ID", "")
GUILD_ID = int(GUILD_ID_STR) if GUILD_ID_STR.isdigit() else None

MAIN_ADMIN_ID_STR = os.getenv("MAIN_ADMIN_ID", "")
MAIN_ADMIN_ID = int(MAIN_ADMIN_ID_STR) if MAIN_ADMIN_ID_STR.isdigit() else 0

VPS_USER_ROLE_ID_STR = os.getenv("VPS_USER_ROLE_ID", "")
VPS_USER_ROLE_ID = int(VPS_USER_ROLE_ID_STR) if VPS_USER_ROLE_ID_STR.isdigit() else None

YOUR_SERVER_IP = os.getenv("YOUR_SERVER_IP", "127.0.0.1")
DEFAULT_STORAGE_POOL = os.getenv("DEFAULT_STORAGE_POOL", "default")
BOT_NAME = os.getenv("BOT_NAME", "LXC Bot V9")
BOT_VERSION = os.getenv("BOT_VERSION", "9.0.0")
BOT_DEVELOPER = os.getenv("BOT_DEVELOPER", "Console")

DEFAULT_CPU_THRESHOLD = int(os.getenv("DEFAULT_CPU_THRESHOLD", "90"))
DEFAULT_RAM_THRESHOLD = int(os.getenv("DEFAULT_RAM_THRESHOLD", "90"))
MONITOR_INTERVAL_SECONDS = int(os.getenv("MONITOR_INTERVAL_SECONDS", "60"))

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("lxc_bot.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("LXC_Bot")

# OS Options for VPS Creation and Reinstallation
OS_OPTIONS = [
    {"label": "Ubuntu 24.04 LTS (Noble)", "value": "images:ubuntu/24.04"},
    {"label": "Ubuntu 22.04 LTS (Jammy)", "value": "images:ubuntu/22.04"},
    {"label": "Debian 12 (Bookworm)", "value": "images:debian/12"},
    {"label": "Debian 11 (Bullseye)", "value": "images:debian/11"},
    {"label": "Alpine Linux 3.20", "value": "images:alpine/3.20"},
    {"label": "CentOS Stream 9", "value": "images:centos/9-Stream"},
    {"label": "Rocky Linux 9", "value": "images:rockylinux/9"}
]

# Database File
DB_FILE = "vps.db"

# ==========================================
# DATABASE INITIALIZATION & ASYNC HELPERS
# ==========================================

async def init_db() -> None:
    """Initialize SQLite database tables and default data asynchronously."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA journal_mode=WAL")
        
        # Admins Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                user_id TEXT PRIMARY KEY
            )
        """)
        
        # Seed Main Admin
        if MAIN_ADMIN_ID:
            await db.execute(
                "INSERT OR IGNORE INTO admins (user_id) VALUES (?)",
                (str(MAIN_ADMIN_ID),)
            )
            
        # Nodes Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS nodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                location TEXT NOT NULL,
                total_vps INTEGER NOT NULL,
                tags TEXT DEFAULT '[]',
                api_key TEXT,
                url TEXT,
                is_local INTEGER DEFAULT 0,
                ssh_host TEXT,
                ssh_port INTEGER DEFAULT 22,
                ssh_user TEXT,
                ssh_pass TEXT,
                ssh_key TEXT
            )
        """)
        
        # Check and Seed Default Local Node
        async with db.execute("SELECT COUNT(*) as count FROM nodes WHERE is_local = 1") as cursor:
            row = await cursor.fetchone()
            if row and row["count"] == 0:
                await db.execute("""
                    INSERT INTO nodes (name, location, total_vps, tags, is_local)
                    VALUES (?, ?, ?, ?, ?)
                """, ("Local Node", "Local Host", 50, "['local', 'ssd']", 1))
                
        # VPS Instances Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS vps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                node_id INTEGER NOT NULL DEFAULT 1,
                container_name TEXT UNIQUE NOT NULL,
                ram TEXT NOT NULL,
                cpu TEXT NOT NULL,
                storage TEXT NOT NULL,
                config TEXT NOT NULL,
                os_version TEXT DEFAULT 'images:ubuntu/22.04',
                status TEXT DEFAULT 'stopped',
                suspended INTEGER DEFAULT 0,
                whitelisted INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                shared_with TEXT DEFAULT '[]',
                suspension_history TEXT DEFAULT '[]',
                FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE RESTRICT
            )
        """)
        
        # Global Settings Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('cpu_threshold', ?)", (str(DEFAULT_CPU_THRESHOLD),))
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('ram_threshold', ?)", (str(DEFAULT_RAM_THRESHOLD),))
        
        # Port Forward Allocation & Mappings
        await db.execute("""
            CREATE TABLE IF NOT EXISTS port_allocations (
                user_id TEXT PRIMARY KEY,
                allocated_ports INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS port_forwards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                vps_container TEXT NOT NULL,
                vps_port INTEGER NOT NULL,
                host_port INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        await db.commit()
    logger.info("Database initialized successfully.")

# Database Access Context Manager or Async Helpers
async def is_db_admin(user_id: int) -> bool:
    """Check if user is a bot administrator."""
    if user_id == MAIN_ADMIN_ID:
        return True
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT 1 FROM admins WHERE user_id = ?", (str(user_id),)) as cursor:
            return await cursor.fetchone() is not None

async def get_node_by_id(node_id: int) -> Optional[Dict[str, Any]]:
    """Retrieve node details by ID."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM nodes WHERE id = ?", (node_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

async def get_node_by_name(name: str) -> Optional[Dict[str, Any]]:
    """Retrieve node details by name."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM nodes WHERE name = ?", (name,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

async def get_all_nodes() -> List[Dict[str, Any]]:
    """Retrieve list of all registered nodes."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM nodes") as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]

async def get_all_vps() -> List[Dict[str, Any]]:
    """Retrieve all VPS container entries."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vps") as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]

async def get_user_vps(user_id: int) -> List[Dict[str, Any]]:
    """Retrieve all VPS owned by a specific user."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vps WHERE user_id = ?", (str(user_id),)) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]

async def get_vps_by_container(container_name: str) -> Optional[Dict[str, Any]]:
    """Retrieve specific VPS by container name."""
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vps WHERE container_name = ?", (container_name,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None

# ==========================================
# CORE UNIFIED COMMAND EXECUTOR (LOCAL/REMOTE)
# ==========================================

async def execute_node_command(node: Dict[str, Any], cmd: str, timeout: int = 120) -> str:
    """
    Unified executor to run shell commands on specified node asynchronously.
    Supports: Local Subprocess, REST API Agent (HTTP), and SSH.
    """
    is_local = node.get("is_local", 0) == 1
    
    if is_local:
        try:
            # Execute command locally asynchronously
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise asyncio.TimeoutError(f"Command execution timed out after {timeout} seconds on local node.")
                
            if proc.returncode != 0:
                err_msg = stderr.decode().strip() or f"Process failed with exit code {proc.returncode}"
                raise Exception(err_msg)
            return stdout.decode().strip()
        except Exception as e:
            logger.error(f"Local command execution failure: {e}")
            raise
            
    else:
        # Remote execution options
        api_url = node.get("url")
        api_key = node.get("api_key")
        
        # Priority 1: REST API Agent
        if api_url and api_key:
            endpoint = f"{api_url.rstrip('/')}/api/execute"
            headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
            payload = {"command": cmd, "timeout": timeout}
            
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(endpoint, json=payload, headers=headers, timeout=timeout + 5) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if data.get("returncode", 0) != 0:
                                raise Exception(data.get("stderr", "Remote execution error via REST API."))
                            return data.get("stdout", "").strip()
                        else:
                            resp_text = await resp.text()
                            raise Exception(f"Node REST API returned status code {resp.status}: {resp_text}")
            except Exception as e:
                logger.warning(f"Failed remote execution via REST API on '{node.get('name')}': {e}. Attempting SSH fallback...")
                
        # Priority 2: SSH Connection
        ssh_host = node.get("ssh_host") or os.getenv("SSH_HOST")
        ssh_port = int(node.get("ssh_port") or os.getenv("SSH_PORT", "22"))
        ssh_user = node.get("ssh_user") or os.getenv("SSH_USERNAME", "root")
        ssh_pass = node.get("ssh_pass") or os.getenv("SSH_PASSWORD")
        ssh_key_path = node.get("ssh_key") or os.getenv("SSH_KEY_PATH")
        
        if not ssh_host:
            raise Exception(f"No connection criteria (REST API URL or SSH Host) specified for remote node '{node.get('name')}'")
            
        try:
            conn_args = {}
            if ssh_key_path:
                conn_args["client_keys"] = [ssh_key_path]
            if ssh_pass:
                conn_args["password"] = ssh_pass
                
            # Trust host keys automatically in sandboxed cluster environment
            conn_args["known_hosts"] = None
            
            async with asyncssh.connect(ssh_host, port=ssh_port, username=ssh_user, **conn_args) as conn:
                result = await conn.run(cmd, timeout=timeout)
                if result.exit_status != 0:
                    raise Exception(result.stderr.strip() or f"SSH execution returned non-zero code: {result.exit_status}")
                return result.stdout.strip()
        except Exception as e:
            logger.error(f"SSH execution failure on remote node '{node.get('name')}': {e}")
            raise

# ==========================================
# LXC CONTAINER SPECIFIC UTILITIES
# ==========================================

async def apply_lxc_permissions(container_name: str, node: Dict[str, Any]) -> None:
    """Applies nested virtualization, privileged and kernel features for full Docker capability inside LXC."""
    configs = [
        "security.nesting true",
        "security.privileged true",
        "security.syscalls.intercept.mknod true",
        "security.syscalls.intercept.setxattr true",
        "linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables,netlink_diag,br_netfilter"
    ]
    
    for conf in configs:
        try:
            await execute_node_command(node, f"lxc config set {container_name} {conf}")
        except Exception as e:
            logger.warning(f"Could not apply LXC configuration '{conf}' to container '{container_name}': {e}")
            
    # Apply raw LXC apparmor allow profile rules
    raw_lxc_profile = (
        "lxc.apparmor.profile = unconfined\\n"
        "lxc.apparmor.allow_nesting = 1\\n"
        "lxc.apparmor.allow_incomplete = 1\\n"
        "lxc.cap.drop =\\n"
        "lxc.cgroup.devices.allow = a\\n"
        "lxc.cgroup2.devices.allow = a\\n"
        "lxc.mount.auto = proc:rw sys:rw cgroup:rw shmounts:rw\\n"
        "lxc.mount.entry = /dev/fuse dev/fuse none bind,create=file 0 0"
    )
    
    try:
        await execute_node_command(node, f"lxc config set {container_name} raw.lxc '{raw_lxc_profile}'")
    except Exception as e:
        logger.warning(f"Could not apply raw apparmor override profile to '{container_name}': {e}")
        
    # Attempt to mount fuse device inside LXC
    try:
        await execute_node_command(node, f"lxc config device add {container_name} fuse unix-char path=/dev/fuse")
    except Exception:
        pass # Ignored if already exists or unsupported

async def apply_lxc_internal_sysctl(container_name: str, node: Dict[str, Any]) -> None:
    """Updates host-level configuration and unprivileged kernel sysctls inside container after start."""
    # Wait briefly for standard processes to start up
    await asyncio.sleep(4)
    commands = [
        "mkdir -p /etc/sysctl.d/",
        "echo 'net.ipv4.ip_unprivileged_port_start=0' > /etc/sysctl.d/99-custom.conf",
        "echo 'net.ipv4.ping_group_range=0 2147483647' >> /etc/sysctl.d/99-custom.conf",
        "echo 'fs.inotify.max_user_watches=524288' >> /etc/sysctl.d/99-custom.conf",
        "echo 'kernel.unprivileged_userns_clone=1' >> /etc/sysctl.d/99-custom.conf",
        "sysctl -p /etc/sysctl.d/99-custom.conf || true"
    ]
    for cmd in commands:
        try:
            await execute_node_command(node, f"lxc exec {container_name} -- bash -c \"{cmd}\"")
        except Exception as e:
            logger.warning(f"Failed applying internal sysctl '{cmd}' in '{container_name}': {e}")

async def get_container_live_metrics(container_name: str, node: Dict[str, Any]) -> Dict[str, Any]:
    """Retrieve detailed resource statistics of a running LXC container asynchronously."""
    # Defaults
    metrics = {
        "status": "unknown",
        "cpu_pct": 0.0,
        "ram_used_mb": 0.0,
        "ram_total_mb": 0.0,
        "ram_pct": 0.0,
        "disk_info": "Unknown",
        "uptime": "Unknown",
        "ips": []
    }
    
    try:
        # Check current container status
        info_raw = await execute_node_command(node, f"lxc info {container_name}")
        for line in info_raw.splitlines():
            line = line.strip()
            if line.startswith("Status:"):
                metrics["status"] = line.split(":", 1)[1].strip().lower()
            elif line.startswith("Uptime:"):
                metrics["uptime"] = line.split(":", 1)[1].strip()
                
        # Retrieve IP addresses from lxc list
        try:
            list_json = await execute_node_command(node, f"lxc list {container_name} --format=json")
            list_data = json.loads(list_json)
            if list_data and len(list_data) > 0:
                state = list_data[0].get("state", {})
                ips = []
                for iface in state.get("network", {}).values():
                    for addr in iface.get("addresses", []):
                        if addr.get("family") == "inet":
                            ips.append(addr.get("address"))
                metrics["ips"] = ips
        except Exception as e:
            logger.warning(f"Failed getting IPs for {container_name}: {e}")
            
        if metrics["status"] == "running":
            # Memory Stats
            try:
                mem_raw = await execute_node_command(node, f"lxc exec {container_name} -- free -m")
                lines = mem_raw.splitlines()
                for line in lines:
                    if line.startswith("Mem:"):
                        parts = line.split()
                        metrics["ram_total_mb"] = float(parts[1])
                        metrics["ram_used_mb"] = float(parts[2])
                        metrics["ram_pct"] = (metrics["ram_used_mb"] / metrics["ram_total_mb"]) * 100 if metrics["ram_total_mb"] > 0 else 0.0
            except Exception:
                pass
                
            # CPU Usage Percent
            try:
                cpu_raw = await execute_node_command(node, f"lxc exec {container_name} -- top -b -n1")
                lines = cpu_raw.splitlines()
                for line in lines:
                    if "%Cpu(s):" in line or "CPU:" in line:
                        parts = line.split()
                        # Extract idle percent
                        idle = 100.0
                        for idx, word in enumerate(parts):
                            if "id" in word:
                                idle = float(parts[idx - 1].replace(",", ".").replace("%", ""))
                                break
                        metrics["cpu_pct"] = max(0.0, 100.0 - idle)
            except Exception:
                pass
                
            # Disk Space Stats
            try:
                disk_raw = await execute_node_command(node, f"lxc exec {container_name} -- df -h /")
                lines = disk_raw.splitlines()
                if len(lines) > 1:
                    parts = lines[1].split()
                    if len(parts) >= 5:
                        metrics["disk_info"] = f"{parts[2]} / {parts[1]} ({parts[4]})"
            except Exception:
                pass
                
    except Exception as e:
         logger.error(f"Error fetching live container metrics for '{container_name}': {e}")
         
    return metrics

async def recreate_vps_forwards(container_name: str, node: Dict[str, Any]) -> int:
    """Rebuilds proxy device bindings on LXC for all allocated ports in the DB."""
    count = 0
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM port_forwards WHERE vps_container = ?", (container_name,)) as cursor:
            rows = await cursor.fetchall()
            for r in rows:
                vps_port = r["vps_port"]
                host_port = r["host_port"]
                
                # Setup custom TCP and UDP proxy devices in LXD for port mappings
                tcp_device = f"tcp_proxy_{host_port}"
                udp_device = f"udp_proxy_{host_port}"
                
                # Check and add TCP Device
                try:
                    await execute_node_command(node, f"lxc config device add {container_name} {tcp_device} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}")
                    count += 1
                except Exception as e:
                    logger.warning(f"Error adding TCP device {tcp_device} for '{container_name}': {e}")
                    
                # Check and add UDP Device
                try:
                    await execute_node_command(node, f"lxc config device add {container_name} {udp_device} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}")
                    count += 1
                except Exception as e:
                    logger.warning(f"Error adding UDP device {udp_device} for '{container_name}': {e}")
                    
    return count

# ==========================================
# PREMIUM EMBED & COMPONENT CREATION FACTORY
# ==========================================

def create_base_embed(title: str, description: str = "", color: int = 0x5865F2) -> discord.Embed:
    """Creates a stylized Embed designed with elegant spacing and corporate aesthetic."""
    embed = discord.Embed(
        title=f"💫 {BOT_NAME} - {title}",
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    # Using modern, reliable server illustration thumbnail
    embed.set_thumbnail(url="https://images.unsplash.com/photo-1600132806370-bf17e65e942f?q=80&w=256&auto=format&fit=crop")
    embed.set_footer(
        text=f"Platform v{BOT_VERSION} • Developed by {BOT_DEVELOPER}",
        icon_url="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=128&auto=format&fit=crop"
    )
    return embed

def create_success_embed(title: str, description: str = "") -> discord.Embed:
    return create_base_embed(title, description, color=0x2ECC71)

def create_error_embed(title: str, description: str = "") -> discord.Embed:
    return create_base_embed(title, description, color=0xE74C3C)

def create_warning_embed(title: str, description: str = "") -> discord.Embed:
    return create_base_embed(title, description, color=0xF1C40F)

# ==========================================
# INTERACTIVE VIEWS, SELECTION MENUS & BUTTONS
# ==========================================

class NodeDropdown(discord.ui.Select):
    def __init__(self, nodes: List[Dict[str, Any]], callback_fn):
        options = [
            discord.SelectOption(
                label=n["name"],
                value=str(n["id"]),
                description=f"{n['location']} | Capacity: {n['total_vps']} VPS Max",
                emoji="🌐" if n["is_local"] == 0 else "🖥️"
            ) for n in nodes
        ]
        super().__init__(placeholder="Select Deployment Node Cluster...", min_values=1, max_values=1, options=options)
        self.callback_fn = callback_fn
        
    async def callback(self, interaction: discord.Interaction):
        await self.callback_fn(interaction, int(self.values[0]))

class OSDropdown(discord.ui.Select):
    def __init__(self, callback_fn):
        options = [
            discord.SelectOption(
                label=o["label"],
                value=o["value"],
                emoji="🐧"
            ) for o in OS_OPTIONS
        ]
        super().__init__(placeholder="Select Guest OS Version...", min_values=1, max_values=1, options=options)
        self.callback_fn = callback_fn
        
    async def callback(self, interaction: discord.Interaction):
        await self.callback_fn(interaction, self.values[0])

class HelpCategoryDropdown(discord.ui.Select):
    def __init__(self, categories: Dict[str, Any], change_callback):
        options = [
            discord.SelectOption(
                label=cat["name"],
                value=key,
                description=cat.get("desc", ""),
                emoji=cat.get("emoji", "📁")
            ) for key, cat in categories.items()
        ]
        super().__init__(placeholder="Browse Command Directories...", min_values=1, max_values=1, options=options)
        self.change_callback = change_callback
        
    async def callback(self, interaction: discord.Interaction):
        await self.change_callback(interaction, self.values[0])

class ConfirmModal(discord.ui.Modal, title="Destructive Action Confirmation"):
    confirm_text = discord.ui.TextInput(
        label="Type 'CONFIRM' to execute action:",
        placeholder="CONFIRM",
        required=True,
        max_length=10
    )
    
    def __init__(self, on_confirm_fn):
        super().__init__()
        self.on_confirm_fn = on_confirm_fn
        
    async def on_submit(self, interaction: discord.Interaction):
        if self.confirm_text.value.upper() == "CONFIRM":
            await self.on_confirm_fn(interaction)
        else:
            await interaction.response.send_message(
                embed=create_error_embed("Validation Error", "Confirmation mismatch. Operation cancelled."),
                ephemeral=True
            )

class InteractiveManageView(discord.ui.View):
    def __init__(self, bot, user_id: int, vps_list: List[Dict[str, Any]], is_admin_ctx: bool = False):
        super().__init__(timeout=300)
        self.bot = bot
        self.user_id = user_id
        self.vps_list = vps_list
        self.is_admin_ctx = is_admin_ctx
        self.current_idx = 0
        
        # Populate selector if user has multiple VPS nodes
        if len(self.vps_list) > 1:
            vps_options = [
                discord.SelectOption(
                    label=f"VPS #{idx+1} ({vps['container_name']})",
                    description=vps["config"],
                    value=str(idx),
                    emoji="🎛️"
                ) for idx, vps in enumerate(self.vps_list)
            ]
            self.vps_select = discord.ui.Select(
                placeholder="Choose Container Workspace...",
                min_values=1,
                max_values=1,
                options=vps_options,
                row=0
            )
            self.vps_select.callback = self.on_vps_select_change
            self.add_item(self.vps_select)
            
    async def on_vps_select_change(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id and not self.is_admin_ctx:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "This control console is locked to the original command sender."), ephemeral=True)
            return
        self.current_idx = int(self.vps_select.values[0])
        await interaction.response.defer()
        await self.refresh_dashboard_message(interaction)

    async def refresh_dashboard_message(self, interaction: discord.Interaction):
        vps = self.vps_list[self.current_idx]
        node = await get_node_by_id(vps["node_id"])
        
        # Immediate visual load indicator
        embed = create_base_embed("Workspace Dashboard", f"Querying real-time container metrics for `{vps['container_name']}`...")
        await interaction.edit_original_response(embed=embed, view=self)
        
        if not node:
            embed = create_error_embed("Hardware Unreachable", "The deployment node hosting this VPS could not be matched in database.")
            await interaction.edit_original_response(embed=embed, view=self)
            return
            
        metrics = await get_container_live_metrics(vps["container_name"], node)
        
        # Build layout with metrics
        status_raw = metrics["status"].upper()
        status_emoji = "🟢" if status_raw == "RUNNING" else "🔴" if status_raw == "STOPPED" else "⚠️"
        
        embed = create_base_embed(
            f"Workspace Dashboard",
            f"Deployment node parent: **{node['name']}** ({node['location']})"
        )
        embed.add_field(name="🏷️ Instance Name", value=f"`{vps['container_name']}`", inline=True)
        embed.add_field(name="🔋 Current State", value=f"{status_emoji} `{status_raw}`", inline=True)
        embed.add_field(name="⏱️ Node Uptime", value=f"`{metrics['uptime']}`", inline=True)
        
        # Live Resource Consumption Gauges
        cpu_gauge = "█" * int(metrics["cpu_pct"] / 10) + "░" * (10 - int(metrics["cpu_pct"] / 10))
        ram_pct = metrics["ram_pct"]
        ram_gauge = "█" * int(ram_pct / 10) + "░" * (10 - int(ram_pct / 10))
        
        embed.add_field(name="🧠 CPU Usage", value=f"`{metrics['cpu_pct']:.1f}%`\n`[{cpu_gauge}]`", inline=True)
        embed.add_field(name="💾 RAM Utilization", value=f"`{metrics['ram_used_mb']:.0f}MB / {metrics['ram_total_mb']:.0f}MB` (`{ram_pct:.1f}%`)\n`[{ram_gauge}]`", inline=True)
        embed.add_field(name="💿 Disk Space", value=f"`{metrics['disk_info']}`", inline=True)
        
        # Details & Port Configuration summary
        ips_text = ", ".join(metrics["ips"]) if metrics["ips"] else "No IP Assigned"
        embed.add_field(name="🌐 Internal IPs", value=f"`{ips_text}`", inline=False)
        embed.add_field(name="⚙️ Assigned Resources", value=f"Allocated Limit: `{vps['config']}`", inline=False)
        embed.add_field(name="🐧 OS Base", value=f"`{vps.get('os_version', 'images:ubuntu/22.04')}`", inline=True)
        
        # Check suspended or whitelisted labels
        extra_status = []
        if vps.get("suspended", 0) == 1:
            extra_status.append("🔴 **SUSPENDED BY SYSTEM AUDIT**")
        if vps.get("whitelisted", 0) == 1:
            extra_status.append("⭐ **EXEMPT FROM AUTO-SUSPENSION**")
            
        if extra_status:
            embed.add_field(name="🛡️ System Flags", value="\n".join(extra_status), inline=False)
            
        await interaction.edit_original_response(embed=embed, view=self)

    # Dashboard Button Action Controls
    @discord.ui.button(label="Start VPS", style=discord.ButtonStyle.success, emoji="▶️", row=1)
    async def start_vps_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id and not self.is_admin_ctx:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Authorized workspace owners only."), ephemeral=True)
            return
            
        vps = self.vps_list[self.current_idx]
        if vps.get("suspended", 0) == 1:
            await interaction.response.send_message(embed=create_error_embed("System Lockout", "This VPS is currently suspended. Please resolve this with system administrators."), ephemeral=True)
            return
            
        await interaction.response.defer()
        node = await get_node_by_id(vps["node_id"])
        if not node:
            return
            
        try:
            await execute_node_command(node, f"lxc start {vps['container_name']}")
            # Apply permissions and sysctls
            await apply_lxc_permissions(vps["container_name"], node)
            await apply_lxc_internal_sysctl(vps["container_name"], node)
            await recreate_vps_forwards(vps["container_name"], node)
            
            # Update Local DB state
            async with aiosqlite.connect(DB_FILE) as db:
                await db.execute("UPDATE vps SET status = 'running' WHERE container_name = ?", (vps["container_name"],))
                await db.commit()
                
            vps["status"] = "running"
            await interaction.followup.send(embed=create_success_embed("Container Active", f"`{vps['container_name']}` activated on `{node['name']}` successfully."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Power State Error", f"Failed starting container: `{e}`"), ephemeral=True)
            
        await self.refresh_dashboard_message(interaction)

    @discord.ui.button(label="Stop VPS", style=discord.ButtonStyle.secondary, emoji="⏹️", row=1)
    async def stop_vps_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id and not self.is_admin_ctx:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Authorized workspace owners only."), ephemeral=True)
            return
            
        vps = self.vps_list[self.current_idx]
        await interaction.response.defer()
        node = await get_node_by_id(vps["node_id"])
        if not node:
            return
            
        try:
            await execute_node_command(node, f"lxc stop {vps['container_name']} --timeout=15 --force")
            
            # Update DB state
            async with aiosqlite.connect(DB_FILE) as db:
                await db.execute("UPDATE vps SET status = 'stopped' WHERE container_name = ?", (vps["container_name"],))
                await db.commit()
                
            vps["status"] = "stopped"
            await interaction.followup.send(embed=create_success_embed("Container Stopped", f"`{vps['container_name']}` has been gracefully shut down."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Power State Error", f"Failed stopping container: `{e}`"), ephemeral=True)
            
        await self.refresh_dashboard_message(interaction)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, emoji="🔄", row=1)
    async def restart_vps_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id and not self.is_admin_ctx:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Authorized workspace owners only."), ephemeral=True)
            return
            
        vps = self.vps_list[self.current_idx]
        if vps.get("suspended", 0) == 1:
            await interaction.response.send_message(embed=create_error_embed("System Lockout", "This VPS is currently suspended. Please resolve this with system administrators."), ephemeral=True)
            return
            
        await interaction.response.defer()
        node = await get_node_by_id(vps["node_id"])
        if not node:
            return
            
        try:
            await execute_node_command(node, f"lxc restart {vps['container_name']} --timeout=15 --force")
            await apply_lxc_permissions(vps["container_name"], node)
            await apply_lxc_internal_sysctl(vps["container_name"], node)
            await recreate_vps_forwards(vps["container_name"], node)
            
            # Update DB
            async with aiosqlite.connect(DB_FILE) as db:
                await db.execute("UPDATE vps SET status = 'running' WHERE container_name = ?", (vps["container_name"],))
                await db.commit()
                
            vps["status"] = "running"
            await interaction.followup.send(embed=create_success_embed("Reboot Complete", f"`{vps['container_name']}` was rebooted on node `{node['name']}`."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Power State Error", f"Failed restarting container: `{e}`"), ephemeral=True)
            
        await self.refresh_dashboard_message(interaction)

    @discord.ui.button(label="Remote Console", style=discord.ButtonStyle.secondary, emoji="🔑", row=2)
    async def create_tmate_session_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id and not self.is_admin_ctx:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Authorized workspace owners only."), ephemeral=True)
            return
            
        vps = self.vps_list[self.current_idx]
        if vps.get("suspended", 0) == 1:
            await interaction.response.send_message(embed=create_error_embed("System Lockout", "This VPS is currently suspended. Remote access disabled."), ephemeral=True)
            return
            
        await interaction.response.defer(ephemeral=True)
        node = await get_node_by_id(vps["node_id"])
        if not node:
            return
            
        try:
            await interaction.followup.send(embed=create_base_embed("Session Setup", "Starting instant SSH sharing service (`tmate`) inside container workspace..."), ephemeral=True)
            
            # Check if tmate is pre-installed in guest OS container
            check_tmate = await execute_node_command(node, f"lxc exec {vps['container_name']} -- which tmate", timeout=15)
            if not check_tmate.strip():
                # Attempt to install package dependencies
                await execute_node_command(node, f"lxc exec {vps['container_name']} -- apt-get update -y")
                await execute_node_command(node, f"lxc exec {vps['container_name']} -- apt-get install tmate -y")
                
            session_id = f"session-{int(time.time())}"
            # Launch tmate background sharing daemon
            await execute_node_command(node, f"lxc exec {vps['container_name']} -- tmate -S /tmp/{session_id}.sock new-session -d")
            await asyncio.sleep(4) # Let socket bind and handshake finish
            
            ssh_connection_string = await execute_node_command(node, f"lxc exec {vps['container_name']} -- tmate -S /tmp/{session_id}.sock display -p '#{{tmate_ssh}}'")
            
            if ssh_connection_string.strip():
                embed = create_success_embed("Encrypted Remote Session Initialized")
                embed.add_field(name="💻 Temporary SSH Access Key", value=f"```bash\n{ssh_connection_string.strip()}\n```", inline=False)
                embed.add_field(name="⏳ Usage Duration", value="This tunnel session expires when your connection closes or terminal workspace is reloaded.", inline=False)
                
                # Try direct DM
                try:
                    await interaction.user.send(embed=embed)
                    await interaction.followup.send(embed=create_success_embed("Access Sent", "Your private credentials have been routed safely to your Direct Messages."), ephemeral=True)
                except discord.Forbidden:
                    # Send ephemerally if DM is closed
                    await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=create_error_embed("Tunnel Failed", "The guest OS tmate daemon failed to retrieve handshake keys. Ensure network rules permit output traffic."), ephemeral=True)
                
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Tunnel Handshake Error", f"Failed starting console: `{e}`"), ephemeral=True)

    @discord.ui.button(label="Reinstall Guest OS", style=discord.ButtonStyle.danger, emoji="⚡", row=2)
    async def reinstall_os_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.user_id and not self.is_admin_ctx:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Authorized workspace owners only."), ephemeral=True)
            return
            
        vps = self.vps_list[self.current_idx]
        if vps.get("suspended", 0) == 1:
            await interaction.response.send_message(embed=create_error_embed("System Lockout", "This VPS is currently suspended. Reinstall disabled."), ephemeral=True)
            return
            
        # Reinstall process involves deleting container entirely, then re-initializing same specifications
        async def perform_reinstall(modal_interaction: discord.Interaction):
            await modal_interaction.response.defer()
            node = await get_node_by_id(vps["node_id"])
            if not node:
                return
                
            try:
                # Force delete the current container
                await modal_interaction.followup.send(embed=create_base_embed("Step 1/3 - Deprovisioning Workspace", "Deprovisioning current instance..."), ephemeral=True)
                await execute_node_command(node, f"lxc delete {vps['container_name']} --force")
                
                # Rebuild
                await modal_interaction.followup.send(embed=create_base_embed("Step 2/3 - Initializing Clean Guest Image", f"Retrieving guest core image `{vps['os_version']}`..."), ephemeral=True)
                await execute_node_command(node, f"lxc init {vps['os_version']} {vps['container_name']} -s {DEFAULT_STORAGE_POOL}")
                
                # Apply limits again
                ram_val = vps["ram"]
                cpu_val = vps["cpu"]
                disk_val = vps["storage"]
                
                if "GB" in ram_val:
                    ram_mb = int(ram_val.replace("GB", "")) * 1024
                    await execute_node_command(node, f"lxc config set {vps['container_name']} limits.memory {ram_mb}MB")
                if cpu_val.isdigit():
                    await execute_node_command(node, f"lxc config set {vps['container_name']} limits.cpu {cpu_val}")
                if "GB" in disk_val:
                    await execute_node_command(node, f"lxc config device set {vps['container_name']} root size={disk_val}")
                    
                # Setup permissions & launch
                await modal_interaction.followup.send(embed=create_base_embed("Step 3/3 - Configuring Advanced Guest System Features", "Rebuilding permissions profile and network proxy paths..."), ephemeral=True)
                await apply_lxc_permissions(vps["container_name"], node)
                await execute_node_command(node, f"lxc start {vps['container_name']}")
                await apply_lxc_internal_sysctl(vps["container_name"], node)
                await recreate_vps_forwards(vps["container_name"], node)
                
                # Update DB Status
                async with aiosqlite.connect(DB_FILE) as db:
                    await db.execute("UPDATE vps SET status = 'running' WHERE container_name = ?", (vps["container_name"],))
                    await db.commit()
                    
                vps["status"] = "running"
                await modal_interaction.followup.send(embed=create_success_embed("Reinstallation Completed Successfully", "Your container OS template has been reset back to dynamic defaults. Initial network ports have been remounted."), ephemeral=True)
            except Exception as e:
                await modal_interaction.followup.send(embed=create_error_embed("Deprovisioning Failure", f"Fatal error executing reset sequence: `{e}`"), ephemeral=True)
                
            await self.refresh_dashboard_message(interaction)
            
        modal = ConfirmModal(on_confirm_fn=perform_reinstall)
        await interaction.response.send_modal(modal)

# ==========================================
# BACKGROUND RESILIENT SYSTEM MONITOR TASK
# ==========================================

class LXCSystemMonitor:
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.monitor_active = True
        
    def start(self) -> None:
        self.bot.loop.create_task(self.run_monitor_loop())
        logger.info("LXC Active Resource Monitor background scheduler started.")
        
    async def run_monitor_loop(self) -> None:
        while self.monitor_active:
            try:
                # Retrieve limits
                cpu_limit = DEFAULT_CPU_THRESHOLD
                ram_limit = DEFAULT_RAM_THRESHOLD
                
                async with aiosqlite.connect(DB_FILE) as db:
                    db.row_factory = aiosqlite.Row
                    async with db.execute("SELECT value FROM settings WHERE key = 'cpu_threshold'") as cur:
                        row = await cur.fetchone()
                        if row: cpu_limit = int(row["value"])
                    async with db.execute("SELECT value FROM settings WHERE key = 'ram_threshold'") as cur:
                        row = await cur.fetchone()
                        if row: ram_limit = int(row["value"])
                        
                # Fetch all registered runtimes
                all_instances = await get_all_vps()
                for inst in all_instances:
                    # Skip suspended or whitelisted targets
                    if inst.get("suspended", 0) == 1 or inst.get("whitelisted", 0) == 1:
                        continue
                        
                    node = await get_node_by_id(inst["node_id"])
                    if not node:
                        continue
                        
                    try:
                        metrics = await get_container_live_metrics(inst["container_name"], node)
                        if metrics["status"] == "running":
                            # Check resource constraints infraction
                            over_cpu = metrics["cpu_pct"] >= cpu_limit
                            over_ram = metrics["ram_pct"] >= ram_limit
                            
                            if over_cpu or over_ram:
                                reason = f"Resource limit breached. CPU: {metrics['cpu_pct']:.1f}% (Limit: {cpu_limit}%), Memory: {metrics['ram_pct']:.1f}% (Limit: {ram_limit}%)"
                                logger.warning(f"AUTO-SUSPENSION TRIGGERED for {inst['container_name']} on node {node['name']}: {reason}")
                                
                                # Shut container down
                                await execute_node_command(node, f"lxc stop {inst['container_name']} --timeout=15 --force")
                                
                                # Audit logs update
                                history = json.loads(inst.get("suspension_history", "[]"))
                                history.append({
                                    "time": datetime.now().isoformat(),
                                    "reason": reason,
                                    "by": "LXC Bot Resource Monitor Guard"
                                })
                                
                                async with aiosqlite.connect(DB_FILE) as db:
                                    await db.execute("""
                                        UPDATE vps 
                                        SET status = 'stopped', suspended = 1, suspension_history = ?
                                        WHERE container_name = ?
                                    """, (json.dumps(history), inst["container_name"]))
                                    await db.commit()
                                    
                                # Route direct private warning notification
                                owner_id = int(inst["user_id"])
                                try:
                                    owner_user = await self.bot.fetch_user(owner_id)
                                    embed = create_warning_embed(
                                        "Automated Instance Protection Guard Activated",
                                        f"Your guest LXC container `{inst['container_name']}` has been suspended automatically to safeguard parent host hardware stability."
                                    )
                                    embed.add_field(name="⚠️ System Intercept Cause", value=reason, inline=False)
                                    embed.add_field(name="📍 Location Node", value=node["name"], inline=True)
                                    embed.add_field(name="⚡ Active Mitigation", value="Please open an admin ticket to review guest process resource optimization or upgrade plan specs.", inline=False)
                                    await owner_user.send(embed=embed)
                                except Exception as dm_e:
                                    logger.warning(f"Could not send DM to user {owner_id} regarding system suspension: {dm_e}")
                    except Exception as e:
                        logger.error(f"Error evaluating guest metrics during daemon loop: {e}")
                        
            except Exception as loop_e:
                logger.error(f"Error in automated monitoring loop cycle: {loop_e}")
                
            await asyncio.sleep(MONITOR_INTERVAL_SECONDS)

# ==========================================
# MAIN DISCORD CLIENT (SLASH TREE BOT)
# ==========================================

class LXCBotV9(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="h!",  # Backwards fallback prefix
            intents=discord.Intents.all(),
            help_command=None
        )
        self.system_monitor = None
        
    async def setup_hook(self) -> None:
        # DB init
        await init_db()
        
        # Start monitoring daemon thread
        self.system_monitor = LXCSystemMonitor(self)
        self.system_monitor.start()
        
        # Immediate command tree synchronization
        if GUILD_ID:
            guild_target = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=guild_target)
            await self.tree.sync(guild=guild_target)
            logger.info(f"Command tree synced to development Guild ID: {GUILD_ID}.")
        else:
            await self.tree.sync()
            logger.info("Command tree synced globally.")

# Launch instance
bot = LXCBotV9()

# ==========================================
# SYSTEM-WIDE SLASH COMMAND REGISTRY
# ==========================================

@bot.tree.command(name="ping", description="Verify gateway routing speed.")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    await interaction.response.send_message(
        embed=create_success_embed("Gateway Operational", f"Bot response latency: `{latency}ms`"),
        ephemeral=True
    )

@bot.tree.command(name="about", description="Render system specifications.")
async def about_platform(interaction: discord.Interaction):
    embed = create_base_embed("Identity", f"Full-stack automated cluster orchestration gateway.")
    embed.add_field(name="🤖 Platform Brand", value=f"`{BOT_NAME}`", inline=True)
    embed.add_field(name="🏷️ System Version", value=f"`v{BOT_VERSION}`", inline=True)
    embed.add_field(name="👑 Developer", value=f"`{BOT_DEVELOPER}`", inline=True)
    embed.add_field(name="⚡ Active Framework", value="`discord.py (v2) & aiohttp/asyncssh`", inline=False)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="myvps", description="List your active LXC environments and configurations.")
async def list_vps_client(interaction: discord.Interaction):
    await interaction.response.defer()
    instances = await get_user_vps(interaction.user.id)
    
    if not instances:
        await interaction.followup.send(
            embed=create_error_embed("No Active Workspaces Found", "You currently do not have any LXC container instances assigned to your profile. Contact system administration to request a node lease.")
        )
        return
        
    embed = create_base_embed("Assigned Infrastructure Workspaces", f"Below is a list of all resources allocated to your client account:")
    
    for idx, vps in enumerate(instances):
        node = await get_node_by_id(vps["node_id"])
        node_name = node["name"] if node else "Unknown Node"
        
        status_text = vps["status"].upper()
        if vps.get("suspended", 0) == 1:
            status_text += " (🔒 SUSPENDED)"
            
        embed.add_field(
            name=f"🖥️ Instance #{idx+1}: {vps['container_name']}",
            value=(
                f"▸ Hardware Specs: `{vps['config']}`\\n"
                f"▸ Running OS: `{vps.get('os_version', 'Unknown')}`\\n"
                f"▸ Cluster Node: `{node_name}`\\n"
                f"▸ Current State: `{status_text}`"
            ),
            inline=False
        )
    await interaction.followup.send(embed=embed)

@bot.tree.command(name="manage", description="Access the full-stack container control center dashboard.")
async def manage_workspace(interaction: discord.Interaction):
    await interaction.response.defer()
    
    # Grab user owned systems
    user_vps_list = await get_user_vps(interaction.user.id)
    
    # Fallback to check if user has admin view capabilities on all nodes
    is_admin_user = await is_db_admin(interaction.user.id)
    if is_admin_user and not user_vps_list:
        # Admins can choose from all system containers if they don't own any personally
        user_vps_list = await get_all_vps()
        
    if not user_vps_list:
        await interaction.followup.send(
            embed=create_error_embed("Control Console Locked", "No matching workspaces registered to your account parameters. Please coordinate with support."),
            ephemeral=True
        )
        return
        
    view = InteractiveManageView(bot, interaction.user.id, user_vps_list, is_admin_ctx=is_admin_user)
    embed = await view.get_initial_embed()
    await interaction.followup.send(embed=embed, view=view)

# Autocomplete methods for Admin interaction helper
async def container_name_autocomplete(interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
    """Generates container selection list for admin commands dynamically."""
    vps_list = await get_all_vps()
    return [
        app_commands.Choice(name=v["container_name"], value=v["container_name"])
        for v in vps_list if current.lower() in v["container_name"].lower()
    ][:25]

async def node_name_autocomplete(interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
    """Generates hardware node selection list dynamically."""
    node_list = await get_all_nodes()
    return [
        app_commands.Choice(name=n["name"], value=n["name"])
        for n in node_list if current.lower() in n["name"].lower()
    ][:25]

# ==========================================
# ADMIN PROVISIONING SYSTEMS
# ==========================================

@bot.tree.command(name="vps-create", description="Lease and deploy a fresh LXC container guest immediately.")
@app_commands.describe(
    target_user="Client profile receiving host resource assignment.",
    ram_gb="RAM capacity ceiling in Gigabytes.",
    cpu_cores="Total hardware virtual CPU threads.",
    storage_gb="Assigned root partition storage capacity limit.",
    os_template="🐧 Target operating system version image to bootstrap.",
    deployment_node="Specific hypervisor cluster machine to bind."
)
@app_commands.autocomplete(deployment_node=node_name_autocomplete)
async def create_vps_admin(
    interaction: discord.Interaction,
    target_user: discord.Member,
    ram_gb: int,
    cpu_cores: int,
    storage_gb: int,
    os_template: str = "images:ubuntu/22.04",
    deployment_node: str = "Local Node"
):
    # Permission verification
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    
    # Grab node parameters
    node = await get_node_by_name(deployment_node)
    if not node:
        await interaction.followup.send(embed=create_error_embed("Node Missing", f"Target hardware cluster `{deployment_node}` not found in database registry."))
        return
        
    # Generate unique cluster identifier container name
    user_id = str(target_user.id)
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT COUNT(*) as count FROM vps WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            instance_num = (row["count"] or 0) + 1
            
    container_name = f"{BOT_NAME.lower().replace(' ', '')}-vps-{user_id}-{instance_num}"
    
    # Validate node hardware capacity
    current_count_async = 0
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT COUNT(*) as count FROM vps WHERE node_id = ?", (node["id"],)) as cursor:
            row = await cursor.fetchone()
            current_count_async = row["count"] or 0
            
    if current_count_async >= node["total_vps"]:
        await interaction.followup.send(embed=create_error_embed("Hardware Exhaustion", f"Deploy node `{node['name']}` has reached maximum rated allocation capacity ({node['total_vps']} containers). Please select another zone."))
        return
        
    try:
        await interaction.followup.send(embed=create_base_embed("Deployment Sequenced", f"Downloading core image `{os_template}` to `{node['name']}` hypervisor and building workspace container..."))
        
        # Perform image bootstrap
        await execute_node_command(node, f"lxc init {os_template} {container_name} -s {DEFAULT_STORAGE_POOL}")
        
        # Apply strict specifications
        ram_mb = ram_gb * 1024
        await execute_node_command(node, f"lxc config set {container_name} limits.memory {ram_mb}MB")
        await execute_node_command(node, f"lxc config set {container_name} limits.cpu {cpu_cores}")
        await execute_node_command(node, f"lxc config device set {container_name} root size={storage_gb}GB")
        
        # Setup nest profiles and start container instance
        await apply_lxc_permissions(container_name, node)
        await execute_node_command(node, f"lxc start {container_name}")
        await apply_lxc_internal_sysctl(container_name, node)
        
        # Commit to core database
        config_summary = f"{ram_gb}GB RAM / {cpu_cores} vCPU / {storage_gb}GB SSD"
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("""
                INSERT INTO vps (user_id, node_id, container_name, ram, cpu, storage, config, os_version, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, node["id"], container_name, f"{ram_gb}GB", str(cpu_cores), f"{storage_gb}GB", config_summary, os_template, "running", datetime.now().isoformat()))
            await db.commit()
            
        # Try adding client access roles
        if VPS_USER_ROLE_ID and interaction.guild:
            try:
                role = interaction.guild.get_role(VPS_USER_ROLE_ID)
                if role: await target_user.add_roles(role)
            except Exception as e:
                logger.warning(f"Failed to assign role to client user: {e}")
                
        # Send deployment success confirmation
        embed = create_success_embed("Infrastructure Allocation Successful", f"Container workspace has been initialized on `{node['name']}` cluster.")
        embed.add_field(name="Owner Client", value=target_user.mention, inline=True)
        embed.add_field(name="LXC Node Instance", value=f"`{container_name}`", inline=True)
        embed.add_field(name="Allocated CPU Profile", value=f"`{cpu_cores} Cores`", inline=True)
        embed.add_field(name="Memory Partition", value=f"`{ram_gb} GB`", inline=True)
        embed.add_field(name="Assigned SSD Disk", value=f"`{storage_gb} GB`", inline=True)
        embed.add_field(name="Operating System Base", value=f"`{os_template}`", inline=False)
        embed.add_field(name="💡 Quick Access Control", value="Workspace is active and powered. Manage this hardware using `/manage` console.", inline=False)
        
        await interaction.followup.send(embed=embed)
        
        # DM Notice to target
        try:
            target_embed = create_success_embed("New Virtual Dedicated Server Deployed", f"An administrator has allocated a high performance LXC system workspace container to your client account.")
            target_embed.add_field(name="Container ID", value=f"`{container_name}`", inline=True)
            target_embed.add_field(name="Assigned Specifications", value=config_summary, inline=True)
            target_embed.add_field(name="Access Command", value="Use `/manage` directly to review status, get root console SSH details, reboot, or reinstall your OS template.", inline=False)
            await target_user.send(embed=target_embed)
        except Exception:
            pass
            
    except Exception as e:
        logger.error(f"Failed deploying LXC VPS workspace: {e}")
        await interaction.followup.send(embed=create_error_embed("Hypervisor Deployment Faulted", f"Error during host deployment setup sequence: `{e}`"))

@bot.tree.command(name="vps-delete", description="Terminate and wipe a guest VPS container instance forever.")
@app_commands.describe(container_name="Target workspace instance to delete.")
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def delete_vps_admin(interaction: discord.Interaction, container_name: str):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    vps = await get_vps_by_container(container_name)
    if not vps:
        await interaction.response.send_message(embed=create_error_embed("Instance Missing", "No matching workspace matches container details in database."), ephemeral=True)
        return
        
    async def perform_deletion(modal_interaction: discord.Interaction):
        await modal_interaction.response.defer()
        node = await get_node_by_id(vps["node_id"])
        
        try:
            # Force close and purge guest container
            if node:
                await execute_node_command(node, f"lxc delete {container_name} --force")
                
            # Remove all associated networking port proxies in SQLite database
            async with aiosqlite.connect(DB_FILE) as db:
                await db.execute("DELETE FROM vps WHERE container_name = ?", (container_name,))
                await db.execute("DELETE FROM port_forwards WHERE vps_container = ?", (container_name,))
                await db.commit()
                
            embed = create_success_embed("Workspace Terminated Successfully", f"All physical hardware resources bound to `{container_name}` have been purged from hypervisor on `{node['name'] if node else 'Host'}`. SQLite mappings removed.")
            await modal_interaction.followup.send(embed=embed)
        except Exception as e:
            await modal_interaction.followup.send(embed=create_error_embed("Deprovisioning Error", f"Failed tearing down container storage: `{e}`"))
            
    modal = ConfirmModal(on_confirm_fn=perform_deletion)
    await interaction.response.send_modal(modal)

@bot.tree.command(name="vps-resize", description="Hot-plug resize guest partition workspace specs.")
@app_commands.describe(
    container_name="LXC container system guest instance.",
    new_ram_gb="Override target memory ceiling in GB.",
    new_cpu_cores="Override target core threads."
)
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def resize_vps_admin(interaction: discord.Interaction, container_name: str, new_ram_gb: int, new_cpu_cores: int):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(container_name)
    if not vps:
        await interaction.followup.send(embed=create_error_embed("Not Found", "Container not matched in database index."))
        return
        
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        ram_mb = new_ram_gb * 1024
        await execute_node_command(node, f"lxc config set {container_name} limits.memory {ram_mb}MB")
        await execute_node_command(node, f"lxc config set {container_name} limits.cpu {new_cpu_cores}")
        
        new_config = f"{new_ram_gb}GB RAM / {new_cpu_cores} vCPU / {vps['storage']} SSD"
        
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("""
                UPDATE vps 
                SET ram = ?, cpu = ?, config = ?
                WHERE container_name = ?
            """, (f"{new_ram_gb}GB", str(new_cpu_cores), new_config, container_name))
            await db.commit()
            
        await interaction.followup.send(embed=create_success_embed("Specifications Resized", f"Container `{container_name}` has been successfully updated to: `{new_config}`."))
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Hardware Modification Faulted", f"Error updating container config specifications: `{e}`"))

@bot.tree.command(name="vps-clone", description="Clone an entire existing guest workspace to a new instance.")
@app_commands.describe(source_container="Active source workspace guest to duplicate.", new_container_name="Unique lowercase destination name.")
@app_commands.autocomplete(source_container=container_name_autocomplete)
async def clone_vps_admin(interaction: discord.Interaction, source_container: str, new_container_name: str):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(source_container)
    if not vps:
        await interaction.followup.send(embed=create_error_embed("Source Missing", "Original container not matched in database index."))
        return
        
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        # Check if container is running; must stop for a clean storage snapshot/clone
        was_running = vps["status"] == "running"
        if was_running:
            await execute_node_command(node, f"lxc stop {source_container}")
            
        await execute_node_command(node, f"lxc copy {source_container} {new_container_name}")
        await apply_lxc_permissions(new_container_name, node)
        
        if was_running:
            await execute_node_command(node, f"lxc start {source_container}")
            await execute_node_command(node, f"lxc start {new_container_name}")
            await apply_lxc_internal_sysctl(new_container_name, node)
            
        # Commit to SQL
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("""
                INSERT INTO vps (user_id, node_id, container_name, ram, cpu, storage, config, os_version, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (vps["user_id"], vps["node_id"], new_container_name, vps["ram"], vps["cpu"], vps["storage"], vps["config"], vps["os_version"], "running" if was_running else "stopped", datetime.now().isoformat()))
            await db.commit()
            
        await interaction.followup.send(embed=create_success_embed("Instance Cloned Successfully", f"Created duplicate instance `{new_container_name}` from `{source_container}` on node cluster `{node['name']}`."))
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Clone Sequence Errored", f"Error copying storage: `{e}`"))

# ==========================================
# GUEST EXECUTION & DIAGNOSTICS CONTROL
# ==========================================

@bot.tree.command(name="vps-exec", description="Run a secure bash shell command directly within container environment.")
@app_commands.describe(container_name="Target container instance.", shell_command="Raw bash command to execute as superuser.")
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def exec_vps_admin(interaction: discord.Interaction, container_name: str, shell_command: str):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(container_name)
    if not vps:
        await interaction.followup.send(embed=create_error_embed("Not Found", "Container not matched in database index."))
        return
        
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        # Wrap command cleanly
        escaped_cmd = shell_command.replace('"', '\\"')
        output = await execute_node_command(node, f"lxc exec {container_name} -- bash -c \"{escaped_cmd}\"")
        
        embed = create_base_embed(f"Terminal Command Results - {container_name}")
        embed.add_field(name="📥 Input Directive", value=f"`{shell_command}`", inline=False)
        
        # Chunk terminal output to fit Discord restrictions cleanly
        output_txt = output[:1000] if output else "Process completed return status with empty stdout."
        embed.add_field(name="📤 Raw Console Output", value=f"```bash\n{output_txt}\n```", inline=False)
        
        await interaction.followup.send(embed=embed)
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Console Command Aborted", f"Error: `{e}`"))

@bot.tree.command(name="vps-logs", description="Retrieve latest guest journalctl boot and service logs.")
@app_commands.describe(container_name="Target container instance.", max_lines="Log buffer output size limit.")
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def logs_vps_admin(interaction: discord.Interaction, container_name: str, max_lines: int = 50):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(container_name)
    if not vps:
        await interaction.followup.send(embed=create_error_embed("Not Found", "Container not matched in database index."))
        return
        
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        output = await execute_node_command(node, f"lxc exec {container_name} -- journalctl -n {max_lines} --no-pager")
        embed = create_base_embed(f"System Log Buffer - {container_name}")
        output_txt = output[-1000:] if output else "Logs buffer empty."
        embed.add_field(name=f"Latest {max_lines} Lines", value=f"```text\n{output_txt}\n```", inline=False)
        await interaction.followup.send(embed=embed)
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Log Query Failed", f"Error: `{e}`"))

# ==========================================
# NETWORKING & PORT MAPPING SERVICES
# ==========================================

@bot.tree.command(name="ports", description="Forward a high-range host node port to your VPS guest port.")
@app_commands.describe(
    action="Operation target.",
    vps_index_num="Index of your VPS (Use '/myvps' to identify number).",
    vps_guest_port="The port your process listens to inside the guest container.",
    forward_id_to_remove="Specified forward ID to revoke (Used under remove action)."
)
async def ports_forward_control(
    interaction: discord.Interaction,
    action: str, # Options: "add", "list", "remove"
    vps_index_num: Optional[int] = None,
    vps_guest_port: Optional[int] = None,
    forward_id_to_remove: Optional[int] = None
):
    await interaction.response.defer()
    user_id = str(interaction.user.id)
    
    # Check current allocations limit
    alloc_ports = 0
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT allocated_ports FROM port_allocations WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row: alloc_ports = row["allocated_ports"]
            
    # Calculate active binds
    active_binds = 0
    async with aiosqlite.connect(DB_FILE) as db:
        async with db.execute("SELECT COUNT(*) as count FROM port_forwards WHERE user_id = ?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row: active_binds = row["count"]
            
    if action.lower() == "list":
        async with aiosqlite.connect(DB_FILE) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM port_forwards WHERE user_id = ?", (user_id,)) as cursor:
                rows = await cursor.fetchall()
                
        embed = create_base_embed("Port Mappings Portal", f"Your allocation limit balance: **{active_binds} / {alloc_ports} Slots Used**")
        if not rows:
            embed.description += "\n\n*No currently active port mapping rules.*"
        for r in rows:
            embed.add_field(
                name=f"Rule ID #{r['id']} | `{r['vps_container']}`",
                value=f"🌐 Internal Port: `{r['vps_port']}` ➔ Node Public Port: `{r['host_port']}`\\n🔗 Connect Address: `{YOUR_SERVER_IP}:{r['host_port']}`",
                inline=False
            )
        await interaction.followup.send(embed=embed)
        return
        
    elif action.lower() == "add":
        if vps_index_num is None or vps_guest_port is None:
            await interaction.followup.send(embed=create_error_embed("Argument Required", "Please provide 'vps_index_num' and 'vps_guest_port' values for mapping rules creation."))
            return
            
        if active_binds >= alloc_ports:
            await interaction.followup.send(embed=create_error_embed("Allocation Quota Exceeded", f"You have reached your total available port forwarding slots limit ({alloc_ports}). Please release some maps or request an upgrade."))
            return
            
        vps_list = await get_user_vps(interaction.user.id)
        if vps_index_num < 1 or vps_index_num > len(vps_list):
            await interaction.followup.send(embed=create_error_embed("Workspace Unmatched", "Selected VPS Index number is invalid."))
            return
            
        vps = vps_list[vps_index_num - 1]
        node = await get_node_by_id(vps["node_id"])
        if not node: return
        
        # Check standard constraints
        if vps_guest_port < 1 or vps_guest_port > 65535:
            await interaction.followup.send(embed=create_error_embed("Port Error", "Guest port parameters must span between 1 and 65535."))
            return
            
        # Allocate random secure high range host port (20000 - 50000)
        host_port = None
        async with aiosqlite.connect(DB_FILE) as db:
            # Query active host ports to ensure absolute conflict mitigation
            async with db.execute("SELECT host_port FROM port_forwards") as cursor:
                used_ports = {row[0] for row in await cursor.fetchall()}
                for _ in range(100):
                    test_port = random.randint(20000, 50000)
                    if test_port not in used_ports:
                        host_port = test_port
                        break
                        
        if not host_port:
            await interaction.followup.send(embed=create_error_embed("Hardware Lockout", "Failed negotiating available high-range host mapping interfaces on cluster."))
            return
            
        try:
            # Inject mappings devices to container
            tcp_device = f"tcp_proxy_{host_port}"
            udp_device = f"udp_proxy_{host_port}"
            
            await execute_node_command(node, f"lxc config device add {vps['container_name']} {tcp_device} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_guest_port}")
            await execute_node_command(node, f"lxc config device add {vps['container_name']} {udp_device} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_guest_port}")
            
            # Commit rule to SQLite
            async with aiosqlite.connect(DB_FILE) as db:
                await db.execute("""
                    INSERT INTO port_forwards (user_id, vps_container, vps_port, host_port, created_at)
                    VALUES (?, ?, ?, ?, ?)
                """, (user_id, vps["container_name"], vps_guest_port, host_port, datetime.now().isoformat()))
                await db.commit()
                
            embed = create_success_embed("Port Forwarding Initialized Successfully")
            embed.add_field(name="Target Container", value=f"`{vps['container_name']}`", inline=True)
            embed.add_field(name="🌐 Internal guest Port", value=f"`{vps_guest_port}`", inline=True)
            embed.add_field(name="📡 External Public Port", value=f"`{host_port}`", inline=True)
            embed.add_field(name="🔗 Connection Hostname Address", value=f"`{YOUR_SERVER_IP}:{host_port}` (Supports TCP/UDP)", inline=False)
            await interaction.followup.send(embed=embed)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Network Rule Setup Failed", f"LXD device setup aborted: `{e}`"))
            
    elif action.lower() == "remove":
        if forward_id_to_remove is None:
            await interaction.followup.send(embed=create_error_embed("ID Missing", "Please input target 'forward_id_to_remove' value to revoke."))
            return
            
        # Check rule ownership
        rule = None
        async with aiosqlite.connect(DB_FILE) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM port_forwards WHERE id = ?", (forward_id_to_remove,)) as cursor:
                rule = await cursor.fetchone()
                
        if not rule or (rule["user_id"] != user_id and not await is_db_admin(interaction.user.id)):
            await interaction.followup.send(embed=create_error_embed("Operation Blocked", "Unmatched record ID or permission restriction."))
            return
            
        vps = await get_vps_by_container(rule["vps_container"])
        if not vps: return
        node = await get_node_by_id(vps["node_id"])
        
        try:
            if node:
                tcp_device = f"tcp_proxy_{rule['host_port']}"
                udp_device = f"udp_proxy_{rule['host_port']}"
                
                await execute_node_command(node, f"lxc config device remove {rule['vps_container']} {tcp_device}")
                await execute_node_command(node, f"lxc config device remove {rule['vps_container']} {udp_device}")
                
            async with aiosqlite.connect(DB_FILE) as db:
                await db.execute("DELETE FROM port_forwards WHERE id = ?", (forward_id_to_remove,))
                await db.commit()
                
            await interaction.followup.send(embed=create_success_embed("Port Rule Cleared", f"Revoked public mapped port `{rule['host_port']}` safely."))
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Device Tear Down Error", f"Failed clearing host mappings: `{e}`"))

# ==========================================
# ADMINISTRATIVE PORTS AND QUOTA SETS
# ==========================================

@bot.tree.command(name="ports-quota", description="Set client account port allocation limits.")
@app_commands.describe(target_user="Target account profile.", slot_amount="Total permissible active rules limit.")
async def admin_set_quota(interaction: discord.Interaction, target_user: discord.Member, slot_amount: int):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    user_id = str(target_user.id)
    
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("""
            INSERT INTO port_allocations (user_id, allocated_ports) 
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET allocated_ports = excluded.allocated_ports
        """, (user_id, slot_amount))
        await db.commit()
        
    await interaction.followup.send(embed=create_success_embed("Account Quotas Saved", f"Client `{target_user.name}` allocated balance slots: `{slot_amount} Active Rules`."))

# ==========================================
# GUEST OS WORKSPACE RESTORATION / BACKUPS
# ==========================================

@bot.tree.command(name="vps-snapshot", description="Write an instant warm point-in-time container state backup.")
@app_commands.describe(container_name="Target container instance.", snapshot_tag="Label index tag.")
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def create_snapshot_admin(interaction: discord.Interaction, container_name: str, snapshot_tag: str):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(container_name)
    if not vps: return
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        await execute_node_command(node, f"lxc snapshot {container_name} {snapshot_tag}")
        await interaction.followup.send(embed=create_success_embed("Snapshot Saved", f"Warm backup point `{snapshot_tag}` generated successfully on hypervisor node."))
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Backup Faulted", f"Error generating state index: `{e}`"))

# ==========================================
# AUTOMATED LEASE INTERCEPT LOCKS (SUSPEND)
# ==========================================

@bot.tree.command(name="vps-suspend", description="Audit lock a container instance immediately.")
@app_commands.describe(container_name="Target container instance.", lock_reason="Detailed cause logging.")
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def suspend_vps_admin(interaction: discord.Interaction, container_name: str, lock_reason: str = "Administrative intercept directive."):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(container_name)
    if not vps: return
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        # Halt container immediately
        await execute_node_command(node, f"lxc stop {container_name} --timeout=15 --force")
        
        history = json.loads(vps.get("suspension_history", "[]"))
        history.append({
            "time": datetime.now().isoformat(),
            "reason": lock_reason,
            "by": f"Admin: {interaction.user.name}"
        })
        
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("""
                UPDATE vps 
                SET status = 'stopped', suspended = 1, suspension_history = ?
                WHERE container_name = ?
            """, (json.dumps(history), container_name))
            await db.commit()
            
        await interaction.followup.send(embed=create_success_embed("System Lock Applied", f"Instance `{container_name}` suspended successfully. User access interfaces revoked."))
        
        # Dispatch notice to target owner
        try:
            owner = await bot.fetch_user(int(vps["user_id"]))
            embed = create_warning_embed("Account Isolation Lock Intercept", f"Your guest LXC machine `{container_name}` has been locked.")
            embed.add_field(name="Reason", value=lock_reason, inline=False)
            await owner.send(embed=embed)
        except Exception:
            pass
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Suspension Execution Faulted", f"Error: `{e}`"))

@bot.tree.command(name="vps-unsuspend", description="Unlock and restore suspended containers.")
@app_commands.describe(container_name="Target container instance to unlock.")
@app_commands.autocomplete(container_name=container_name_autocomplete)
async def unsuspend_vps_admin(interaction: discord.Interaction, container_name: str):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    vps = await get_vps_by_container(container_name)
    if not vps: return
    node = await get_node_by_id(vps["node_id"])
    if not node: return
    
    try:
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("UPDATE vps SET suspended = 0 WHERE container_name = ?", (container_name,))
            await db.commit()
            
        await execute_node_command(node, f"lxc start {container_name}")
        await apply_lxc_internal_sysctl(container_name, node)
        await recreate_vps_forwards(container_name, node)
        
        await interaction.followup.send(embed=create_success_embed("Isolation Restored", f"Container workspace `{container_name}` has been unsuspended and powered back on node `{node['name']}`."))
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Restoration Interrupted", f"Failed restoring: `{e}`"))

# ==========================================
# HARDWARE CLUSTER NODE REGISTRY SUITE
# ==========================================

@bot.tree.command(name="node-create", description="Register a new hardware cluster hypervisor parent.")
@app_commands.describe(
    name="Unique cluster node moniker.",
    location="Geographical deployment sector.",
    capacity_vps="Maximum container leases count threshold limit.",
    api_endpoint_url="REST URL if running cluster agent.",
    api_key="REST token key.",
    ssh_ip="SSH interface address.",
    ssh_port="SSH port limit config."
)
async def add_node_admin(
    interaction: discord.Interaction,
    name: str,
    location: str,
    capacity_vps: int,
    api_endpoint_url: Optional[str] = None,
    api_key: Optional[str] = None,
    ssh_ip: Optional[str] = None,
    ssh_port: int = 22
):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    
    try:
        is_local = 1 if not api_endpoint_url and not ssh_ip else 0
        async with aiosqlite.connect(DB_FILE) as db:
            await db.execute("""
                INSERT INTO nodes (name, location, total_vps, api_key, url, is_local, ssh_host, ssh_port)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (name, location, capacity_vps, api_key, api_endpoint_url, is_local, ssh_ip, ssh_port))
            await db.commit()
            
        await interaction.followup.send(embed=create_success_embed("Cluster Node Registered", f"New hypervisor `{name}` listed in system successfully under location `{location}`."))
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Database Interception Failed", f"Error listing node parameters: `{e}`"))

@bot.tree.command(name="node-list", description="Display all hypervisor clusters status.")
async def node_list_admin(interaction: discord.Interaction):
    if not await is_db_admin(interaction.user.id):
        await interaction.response.send_message(embed=create_error_embed("Unprivileged Execution", "Authorized administrators only."), ephemeral=True)
        return
        
    await interaction.response.defer()
    nodes = await get_all_nodes()
    
    embed = create_base_embed("Cluster Node Directory Overview", f"Registered hardware resources count: **{len(nodes)} Parents**")
    for n in nodes:
        node_type = "🖥️ Local" if n["is_local"] == 1 else "🌐 Remote"
        
        # Check active status dynamically
        status = "🔴 OFFLINE"
        try:
            if n["is_local"] == 1:
                status = "🟢 ONLINE"
            else:
                # Ping REST API
                if n["url"]:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(f"{n['url'].rstrip('/')}/api/ping", timeout=4) as resp:
                            if resp.status == 200: status = "🟢 ONLINE"
        except Exception:
            pass
            
        embed.add_field(
            name=f"🌐 {n['name']} ({n['location']})",
            value=(
                f"▸ Cluster Zone Type: `{node_type}`\\n"
                f"▸ Connection Diagnostics: `{status}`\\n"
                f"▸ Lease Threshold Cap: `{n['total_vps']} Instances MAX`"
            ),
            inline=False
        )
    await interaction.followup.send(embed=embed)

# ==========================================
# CLIENT SHARING DELEGATION PORTAL
# ==========================================

@bot.tree.command(name="share-user", description="Delegate guest workspace access parameters to another Discord user.")
@app_commands.describe(shared_user="Discord account receiving guest dashboard rights.", vps_index_num="Index of owned VPS container.")
async def share_vps_client(interaction: discord.Interaction, shared_user: discord.Member, vps_index_num: int):
    await interaction.response.defer()
    user_id = str(interaction.user.id)
    
    vps_list = await get_user_vps(interaction.user.id)
    if vps_index_num < 1 or vps_index_num > len(vps_list):
        await interaction.followup.send(embed=create_error_embed("Workspace Unmatched", "Selected VPS Index number does not match registered properties."))
        return
        
    vps = vps_list[vps_index_num - 1]
    shared_array = json.loads(vps.get("shared_with", "[]"))
    
    if str(shared_user.id) in shared_array:
        await interaction.followup.send(embed=create_error_embed("Delegation Duplicate", "This client profile already holds permissions coordinates over this container."))
        return
        
    shared_array.append(str(shared_user.id))
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("UPDATE vps SET shared_with = ? WHERE container_name = ?", (json.dumps(shared_array), vps["container_name"]))
        await db.commit()
        
    await interaction.followup.send(embed=create_success_embed("Access Parameters Delegated", f"Collaborator `{shared_user.name}` was successfully added to permissions list of `{vps['container_name']}`. They can access this system on `/manage` Dashboard panels."))

# ==========================================
# COMPREHENSIVE INTERACTIVE HELP DIRECTORY
# ==========================================

@bot.tree.command(name="help", description="Render the interactive command and systems directory guides.")
async def help_directory(interaction: discord.Interaction):
    categories = {
        "user_cat": {
            "name": "👤 Client Workspaces",
            "desc": "Basic operations, status listing and workspace reviews.",
            "emoji": "👤",
            "commands": [
                ("`/myvps`", "Display leased containers details and balance indexes."),
                ("`/manage`", "Launch direct interactive power state dashboard console."),
                ("`/share-user`", "Delegate read/write control boundaries to collaborator profiles.")
            ]
        },
        "network_cat": {
            "name": "🔌 Guest Networking Mappings",
            "desc": "Control port mappings rules TCP/UDP proxy bindings.",
            "emoji": "🔌",
            "commands": [
                ("`/ports action:list`", "List your custom bound port redirection interfaces."),
                ("`/ports action:add`", "Map a dynamic public port coordinates directly inside guest."),
                ("`/ports action:remove`", "Delete network forwarding entry to release slots.")
            ]
        },
        "admin_cat": {
            "name": "🛡️ Administration Orchestration",
            "desc": "Global hypervisor cluster and provisioning boundaries control.",
            "emoji": "🛡️",
            "commands": [
                ("`/vps-create`", "Provision, bootstrap and lease dynamic Guest container nodes."),
                ("`/vps-delete`", "Terminate, unmount storage partitions, and purge systems."),
                ("`/vps-resize`", "Hot-adjust virtual CPU and memory specs partitions."),
                ("`/vps-clone`", "Copy file system allocations clone directly to new zone."),
                ("`/vps-exec`", "Execute direct administrative CLI directives in guest OS root."),
                ("`/vps-logs`", "Audit guest kernel sysctl system logs buffer stream."),
                ("`/vps-suspend`", "Place structural lockdown constraints on leased systems.")
            ]
        },
        "cluster_cat": {
            "name": "🌐 Node Cluster Infrastructure",
            "desc": "Register or modify parent cluster hosts details.",
            "emoji": "🌐",
            "commands": [
                ("`/node-create`", "List a hardware cluster hypervisor zone parent in DB."),
                ("`/node-list`", "Display physical hardware node online diagnostics status.")
            ]
        }
    }
    
    async def category_change_callback(menu_interaction: discord.Interaction, selected_cat: str):
        if menu_interaction.user.id != interaction.user.id:
            await menu_interaction.response.send_message("This interactive guide session has expired for your profile.", ephemeral=True)
            return
            
        cat = categories[selected_cat]
        embed = create_base_embed(f"Systems Directory Directory - {cat['name']}", cat["desc"])
        
        for cmd, desc in cat["commands"]:
            embed.add_field(name=cmd, value=f"➔ {desc}", inline=False)
            
        await menu_interaction.response.edit_message(embed=embed, view=view)
        
    view = discord.ui.View(timeout=180)
    dropdown = HelpCategoryDropdown(categories, category_change_callback)
    view.add_item(dropdown)
    
    initial_embed = create_base_embed(
        "Systems Directory Guide Gateway",
        "Welcome to the **LXC Bot V9** command gateway. Browse structural category directories below to guide your deployment actions."
    )
    initial_embed.add_field(name="🌐 Hardware Network Server Host", value=f"`{YOUR_SERVER_IP}`", inline=True)
    initial_embed.add_field(name="👑 Active Orchestration Gatekeeper", value=bot.user.mention, inline=True)
    
    await interaction.response.send_message(embed=initial_embed, view=view, ephemeral=True)

# ==========================================
# MAIN EXECUTION ENTRY ROUTE
# ==========================================

if __name__ == "__main__":
    if not DISCORD_TOKEN or DISCORD_TOKEN == "YOUR_DISCORD_BOT_TOKEN":
        logger.error("FATAL: DISCORD_TOKEN is missing or contains template string in '.env' configuration directory. Setup aborted.")
        sys.exit(1)
        
    logger.info("Initializing LXC Bot V9 Core Module...")
    bot.run(DISCORD_TOKEN)
