#!/bin/bash

# =================================================================-------------
# VPSDEPLOYBOT Automated Installation and Startup Script
# =================================================================-------------

# Use set -e to exit immediately if a command exits with a non-zero status
set -e

# Colored Output Codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper Functions for Logging
log_success() {
    echo -e "${GREEN}[SUCCESS] $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

log_error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

log_info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

echo -e "${BLUE}"
echo "========================================================================="
echo "                  VPSDEPLOYBOT INSTALLATION WIZARD                       "
echo "========================================================================="
echo -e "${NC}"

# 1. Update Package Lists
log_info "Updating system package lists..."
if sudo apt update; then
    log_success "Package lists updated successfully."
else
    log_error "Failed to update package lists. Please check your internet connection."
    exit 1
fi

# 2. Install Required System Packages (only if missing)
install_if_missing() {
    PACKAGE=$1
    log_info "Checking for package: $PACKAGE..."
    if dpkg -s "$PACKAGE" >/dev/null 2>&1; then
        log_success "Package '$PACKAGE' is already installed."
    else
        log_warning "Package '$PACKAGE' is missing. Installing..."
        if sudo apt install -y "$PACKAGE"; then
            log_success "Package '$PACKAGE' installed successfully."
        else
            log_error "Failed to install package '$PACKAGE'."
            exit 1
        fi
    fi
}

install_if_missing git
install_if_missing python3
install_if_missing python3-pip

# 3. Verify systemctl (systemd) Availability
log_info "Verifying systemctl/systemd availability..."
if command -v systemctl >/dev/null 2>&1; then
    log_success "systemctl is available on this system."
else
    log_warning "systemctl is NOT available. A standard systemd initialization is required for service orchestration."
fi

# 4. Verify Essential Files Exist
check_file_exists() {
    FILE=$1
    log_info "Verifying file existence: $FILE..."
    if [ -f "$FILE" ]; then
        log_success "File '$FILE' exists."
    else
        log_error "Essential file '$FILE' is missing! Installation aborted."
        exit 1
    fi
}

check_file_exists ".env"
check_file_exists "bot.py"
check_file_exists "requirements.txt"

# 5. Install Python Dependencies
log_info "Installing python dependencies from requirements.txt..."
if command -v pip3 >/dev/null 2>&1; then
    if pip3 install -r requirements.txt; then
        log_success "Python dependencies installed successfully using pip3."
    else
        log_error "Failed to install dependencies using pip3."
        exit 1
    fi
else
    log_warning "pip3 command not found. Falling back to python3 -m pip..."
    if python3 -m pip install -r requirements.txt; then
        log_success "Python dependencies installed successfully using python3 -m pip."
    else
        log_error "Failed to install dependencies using fallback pip execution."
        exit 1
    fi
fi

# 6. Configure Environment Variables
log_info "Opening environment file (.env) for configuration..."
if command -v nano >/dev/null 2>&1; then
    nano .env
else
    log_warning "Nano editor is not available. Please edit .env manually before starting. Falling back to simple read..."
fi

# 7. Validate and Run
log_info "Validating configuration file..."
if [ -s ".env" ]; then
    log_success "Configuration file (.env) validated successfully (not empty)."
else
    log_error "Configuration file (.env) is empty! Please populate required variables."
    exit 1
fi

log_success "All validation passes complete! Starting VPSDEPLOYBOT..."
echo "========================================================================="
python3 bot.py
